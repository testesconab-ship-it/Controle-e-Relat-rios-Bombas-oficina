import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { User, RepairOrder, StatusConfig, FieldConfig, DEFAULT_STATUS_CONFIG, DEFAULT_FABRICANTES, TermoGarantiaConfig, UserPermissions, DEFAULT_ADMIN_PERMISSIONS, DEFAULT_USER_PERMISSIONS, FrasePronta, DEFAULT_FRASES_DEFEITO, TipoServicoAnalise, DEFAULT_TIPOS_SERVICO } from '../types';

interface AppContextType {
  // Auth
  currentUser: User | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  
  // Users
  users: User[];
  addUser: (user: Omit<User, 'id' | 'createdAt' | 'permissions'> & { permissions?: UserPermissions }) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;
  
  // Repair Orders
  repairOrders: RepairOrder[];
  addRepairOrder: (order: Omit<RepairOrder, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>) => void;
  updateRepairOrder: (id: string, updates: Partial<RepairOrder>) => void;
  deleteRepairOrder: (id: string) => void;
  getRepairOrderById: (id: string) => RepairOrder | undefined;
  
  // Config
  statusConfig: StatusConfig[];
  updateStatusConfig: (config: StatusConfig[]) => void;
  fieldConfig: FieldConfig[];
  updateFieldConfig: (config: FieldConfig[]) => void;
  
  // Fabricantes (antes era Marcas)
  fabricantes: string[];
  addFabricante: (fabricante: string) => void;
  updateFabricante: (oldFabricante: string, newFabricante: string) => void;
  deleteFabricante: (fabricante: string) => void;
  
  // Frases Prontas para Defeito Relatado
  frasesDefeito: FrasePronta[];
  addFraseDefeito: (texto: string) => void;
  updateFraseDefeito: (id: string, texto: string) => void;
  deleteFraseDefeito: (id: string) => void;
  
  // Tipos de Serviço para Análise Técnica
  tiposServico: TipoServicoAnalise[];
  addTipoServico: (titulo: string, descricaoPadrao: string) => void;
  updateTipoServico: (id: string, titulo: string, descricaoPadrao: string) => void;
  deleteTipoServico: (id: string) => void;
  
  // Termo de Garantia
  termoGarantia: TermoGarantiaConfig;
  updateTermoGarantia: (config: TermoGarantiaConfig) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_USERS: User[] = [
  {
    id: '1',
    name: 'Administrador',
    email: 'admin@conab.com',
    password: 'admin123',
    role: 'admin',
    permissions: DEFAULT_ADMIN_PERMISSIONS,
    createdAt: new Date(),
  },
  {
    id: '2',
    name: 'Técnico João',
    email: 'joao@conab.com',
    password: '123456',
    role: 'user',
    permissions: DEFAULT_USER_PERMISSIONS,
    createdAt: new Date(),
  },
];

const INITIAL_FIELD_CONFIG: FieldConfig[] = [
  { name: 'codigoEntidade', label: 'Código Entidade', required: true, stage: 'entrada' },
  { name: 'nomeCliente', label: 'Nome do Cliente', required: true, stage: 'entrada' },
  { name: 'numeroOS', label: 'Número da OS', required: true, stage: 'entrada' },
  { name: 'numeroTG', label: 'Número do TG', required: true, stage: 'entrada' },
  { name: 'vendedorResponsavel', label: 'Vendedor Responsável', required: true, stage: 'entrada' },
  { name: 'fabricante', label: 'Fabricante', required: true, stage: 'entrada' },
  { name: 'modelo', label: 'Modelo', required: true, stage: 'entrada' },
  { name: 'potencia', label: 'Potência', required: false, stage: 'entrada' },
  { name: 'tensao', label: 'Tensão', required: false, stage: 'entrada' },
  { name: 'tipoFase', label: 'Tipo (Trifásico/Monofásico)', required: false, stage: 'entrada' },
  { name: 'defeitoRelatado', label: 'Defeito Relatado', required: true, stage: 'entrada' },
  { name: 'analiseTecnica', label: 'Análise Técnica em Bancada', required: true, stage: 'analise' },
  { name: 'conclusaoRecomendacao', label: 'Conclusão e Recomendação', required: false, stage: 'analise' },
  { name: 'previsaoEntrega', label: 'Previsão de Entrega', required: true, stage: 'analise' },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('conab_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });
  const [repairOrders, setRepairOrders] = useState<RepairOrder[]>(() => {
    const saved = localStorage.getItem('conab_orders');
    return saved ? JSON.parse(saved) : [];
  });
  const [statusConfig, setStatusConfig] = useState<StatusConfig[]>(() => {
    const saved = localStorage.getItem('conab_status_config');
    return saved ? JSON.parse(saved) : DEFAULT_STATUS_CONFIG;
  });
  const [fieldConfig, setFieldConfig] = useState<FieldConfig[]>(() => {
    const saved = localStorage.getItem('conab_field_config');
    return saved ? JSON.parse(saved) : INITIAL_FIELD_CONFIG;
  });
  const [fabricantes, setFabricantes] = useState<string[]>(() => {
    const saved = localStorage.getItem('conab_fabricantes');
    return saved ? JSON.parse(saved) : DEFAULT_FABRICANTES;
  });
  const [frasesDefeito, setFrasesDefeito] = useState<FrasePronta[]>(() => {
    const saved = localStorage.getItem('conab_frases_defeito');
    return saved ? JSON.parse(saved) : DEFAULT_FRASES_DEFEITO;
  });
  const [tiposServico, setTiposServico] = useState<TipoServicoAnalise[]>(() => {
    const saved = localStorage.getItem('conab_tipos_servico');
    return saved ? JSON.parse(saved) : DEFAULT_TIPOS_SERVICO;
  });
  
  const [termoGarantia, setTermoGarantia] = useState<TermoGarantiaConfig>(() => {
    const saved = localStorage.getItem('conab_termo_garantia');
    return saved ? JSON.parse(saved) : {
      objetoGarantia: 'A Conab+ garante os serviços de reparo e as peças listadas neste relatório pelo prazo de 90 dias, a contar da data de entrega, contra defeitos de fabricação ou montagem.',
      exclusoes: [
        'Instalação elétrica inadequada ou falta de proteção térmica.',
        'Operação a seco ou cavitação.',
        'Rompimento do lacre ou tentativa de reparo por terceiros.'
      ]
    };
  });

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem('conab_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('conab_orders', JSON.stringify(repairOrders));
  }, [repairOrders]);

  useEffect(() => {
    localStorage.setItem('conab_status_config', JSON.stringify(statusConfig));
  }, [statusConfig]);

  useEffect(() => {
    localStorage.setItem('conab_field_config', JSON.stringify(fieldConfig));
  }, [fieldConfig]);

  useEffect(() => {
    localStorage.setItem('conab_fabricantes', JSON.stringify(fabricantes));
  }, [fabricantes]);

  useEffect(() => {
    localStorage.setItem('conab_frases_defeito', JSON.stringify(frasesDefeito));
  }, [frasesDefeito]);

  useEffect(() => {
    localStorage.setItem('conab_tipos_servico', JSON.stringify(tiposServico));
  }, [tiposServico]);

  useEffect(() => {
    localStorage.setItem('conab_termo_garantia', JSON.stringify(termoGarantia));
  }, [termoGarantia]);

  // Check for logged user on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('conab_current_user');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  const login = (email: string, password: string): boolean => {
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
      setCurrentUser(user);
      localStorage.setItem('conab_current_user', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('conab_current_user');
  };

  const addUser = (userData: Omit<User, 'id' | 'createdAt' | 'permissions'> & { permissions?: UserPermissions }) => {
    const defaultPermissions = userData.role === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : DEFAULT_USER_PERMISSIONS;
    const newUser: User = {
      ...userData,
      id: uuidv4(),
      permissions: userData.permissions || defaultPermissions,
      createdAt: new Date(),
    };
    setUsers(prev => [...prev, newUser]);
  };

  const updateUser = (id: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => 
      u.id === id ? { ...u, ...updates } : u
    ));
  };

  const deleteUser = (id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
  };

  const addRepairOrder = (orderData: Omit<RepairOrder, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>) => {
    const newOrder: RepairOrder = {
      ...orderData,
      id: uuidv4(),
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: currentUser?.id || '',
    };
    setRepairOrders(prev => [...prev, newOrder]);
  };

  const updateRepairOrder = (id: string, updates: Partial<RepairOrder>) => {
    setRepairOrders(prev => prev.map(order => 
      order.id === id 
        ? { ...order, ...updates, updatedAt: new Date() }
        : order
    ));
  };

  const deleteRepairOrder = (id: string) => {
    setRepairOrders(prev => prev.filter(o => o.id !== id));
  };

  const getRepairOrderById = (id: string) => {
    return repairOrders.find(o => o.id === id);
  };

  const updateStatusConfig = (config: StatusConfig[]) => {
    setStatusConfig(config);
  };

  const updateFieldConfig = (config: FieldConfig[]) => {
    setFieldConfig(config);
  };

  const addFabricante = (fabricante: string) => {
    if (!fabricantes.includes(fabricante)) {
      setFabricantes(prev => [...prev, fabricante]);
    }
  };

  const updateFabricante = (oldFabricante: string, newFabricante: string) => {
    setFabricantes(prev => prev.map(f => f === oldFabricante ? newFabricante : f));
  };

  const deleteFabricante = (fabricante: string) => {
    setFabricantes(prev => prev.filter(f => f !== fabricante));
  };

  const addFraseDefeito = (texto: string) => {
    const newFrase: FrasePronta = {
      id: uuidv4(),
      texto
    };
    setFrasesDefeito(prev => [...prev, newFrase]);
  };

  const updateFraseDefeito = (id: string, texto: string) => {
    setFrasesDefeito(prev => prev.map(f => f.id === id ? { ...f, texto } : f));
  };

  const deleteFraseDefeito = (id: string) => {
    setFrasesDefeito(prev => prev.filter(f => f.id !== id));
  };

  const addTipoServico = (titulo: string, descricaoPadrao: string) => {
    const newTipo: TipoServicoAnalise = {
      id: uuidv4(),
      titulo,
      descricaoPadrao
    };
    setTiposServico(prev => [...prev, newTipo]);
  };

  const updateTipoServico = (id: string, titulo: string, descricaoPadrao: string) => {
    setTiposServico(prev => prev.map(t => t.id === id ? { ...t, titulo, descricaoPadrao } : t));
  };

  const deleteTipoServico = (id: string) => {
    setTiposServico(prev => prev.filter(t => t.id !== id));
  };

  const updateTermoGarantia = (config: TermoGarantiaConfig) => {
    setTermoGarantia(config);
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      login,
      logout,
      users,
      addUser,
      deleteUser,
      repairOrders,
      addRepairOrder,
      updateRepairOrder,
      deleteRepairOrder,
      getRepairOrderById,
      statusConfig,
      updateStatusConfig,
      fieldConfig,
      updateFieldConfig,
      fabricantes,
      addFabricante,
      updateFabricante,
      deleteFabricante,
      frasesDefeito,
      addFraseDefeito,
      updateFraseDefeito,
      deleteFraseDefeito,
      tiposServico,
      addTipoServico,
      updateTipoServico,
      deleteTipoServico,
      termoGarantia,
      updateTermoGarantia,
      updateUser,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
