import { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Login } from './components/Login';
import { Layout } from './components/Layout';
import { CentralReparos } from './components/CentralReparos';
import { Relatorios } from './components/Relatorios';
import { PainelAdmin } from './components/PainelAdmin';
import { Perfil } from './components/Perfil';

type Tab = 'reparos' | 'relatorios' | 'admin' | 'perfil';

function AppContent() {
  const { currentUser } = useApp();
  const [activeTab, setActiveTab] = useState<Tab>('reparos');

  if (!currentUser) {
    return <Login />;
  }

  const hasTabPermission = (tab: Tab) => {
    if (!currentUser.permissions) return false;
    return currentUser.permissions.tabs.includes(tab);
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {activeTab === 'reparos' && hasTabPermission('reparos') && <CentralReparos />}
      {activeTab === 'relatorios' && hasTabPermission('relatorios') && <Relatorios />}
      {activeTab === 'admin' && hasTabPermission('admin') && <PainelAdmin />}
      {activeTab === 'perfil' && hasTabPermission('perfil') && <Perfil />}
    </Layout>
  );
}

export function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
