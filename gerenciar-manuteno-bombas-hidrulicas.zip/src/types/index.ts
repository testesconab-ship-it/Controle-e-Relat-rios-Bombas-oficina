export type UserRole = 'admin' | 'user';

export type TabPermission = 'reparos' | 'relatorios' | 'admin' | 'perfil';

export type FieldPermission = 
  | 'codigoEntidade' | 'nomeCliente' | 'numeroOS' | 'numeroTG' 
  | 'vendedorResponsavel' | 'classeReceitaDespesa' | 'fabricante' | 'modelo' 
  | 'potencia' | 'tensao' | 'tipoFase'
  | 'defeitoRelatado' | 'veioComConexoes' | 'fotosEntrada'
  | 'mecanicoResponsavel' | 'analiseTecnica' | 'conclusaoRecomendacao' 
  | 'fotosAnalise' | 'fotoPlaquetaBomba' | 'fotoPlaquetaMotor'
  | 'pecasSelecionadas' | 'maoDeObra' | 'previsaoEntrega';

export interface UserPermissions {
  tabs: TabPermission[];
  fields: FieldPermission[];
  canEditOrders: boolean;
  canDeleteOrders: boolean;
  canExportPDF: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  permissions: UserPermissions;
  createdAt: Date;
}

export const DEFAULT_ADMIN_PERMISSIONS: UserPermissions = {
  tabs: ['reparos', 'relatorios', 'admin', 'perfil'],
  fields: [
    'codigoEntidade', 'nomeCliente', 'numeroOS', 'numeroTG',
    'vendedorResponsavel', 'classeReceitaDespesa', 'fabricante', 'modelo',
    'potencia', 'tensao', 'tipoFase',
    'defeitoRelatado', 'veioComConexoes', 'fotosEntrada',
    'mecanicoResponsavel', 'analiseTecnica', 'conclusaoRecomendacao',
    'fotosAnalise', 'fotoPlaquetaBomba', 'fotoPlaquetaMotor',
    'pecasSelecionadas', 'maoDeObra', 'previsaoEntrega'
  ],
  canEditOrders: true,
  canDeleteOrders: true,
  canExportPDF: true
};

export const DEFAULT_USER_PERMISSIONS: UserPermissions = {
  tabs: ['reparos', 'perfil'],
  fields: [
    'codigoEntidade', 'nomeCliente', 'numeroOS', 'numeroTG',
    'vendedorResponsavel', 'classeReceitaDespesa', 'fabricante', 'modelo',
    'potencia', 'tensao', 'tipoFase',
    'defeitoRelatado', 'veioComConexoes', 'fotosEntrada',
    'mecanicoResponsavel', 'analiseTecnica', 'conclusaoRecomendacao',
    'fotosAnalise', 'fotoPlaquetaBomba', 'fotoPlaquetaMotor',
    'pecasSelecionadas', 'maoDeObra', 'previsaoEntrega'
  ],
  canEditOrders: true,
  canDeleteOrders: false,
  canExportPDF: false
};

export type RepairStatus = 'entrada' | 'analise' | 'concluido';

export interface FotoComDescricao {
  url: string;
  descricao: string;
}

export interface Peca {
  id: string;
  codigo: string;
  descricao: string;
  quantidade: number;
}

// Análise Técnica em Bancada - Item de serviço
export interface AnaliseItem {
  id: string;
  titulo: string; // Ex: "Conjunto Hidráulico", "Sistema de Vedação", etc.
  descricao: string; // Descrição detalhada
}

export interface MaoDeObra {
  id: string;
  descricao: string;
  quantidade: number;
}

export interface RepairOrder {
  id: string;
  // Etapa 1: Entrada
  codigoEntidade: string;
  nomeCliente: string;
  numeroOS: string;
  numeroTG: string;
  vendedorResponsavel: string;
  classeReceitaDespesa: string;
  fabricante: string; // Alterado de 'marca' para 'fabricante'
  modelo: string;
  potencia: string; // Novo campo: Ex: "40,0 CV IR3"
  tensao: string; // Novo campo: Ex: "220/380/440 V"
  tipoFase: 'trifasico' | 'monofasico' | ''; // Novo campo
  defeitoRelatado: string;
  veioComConexoes: boolean | null;
  fotosEntrada: FotoComDescricao[];
  
  // Etapa 2: Análise
  mecanicoResponsavel: string;
  analiseTecnica: AnaliseItem[]; // Alterado de descricaoProblema para lista estruturada
  conclusaoRecomendacao: string; // Alterado de justificativaTroca
  fotosAnalise: FotoComDescricao[];
  fotoPlaquetaBomba: FotoComDescricao | null;
  fotoPlaquetaMotor: FotoComDescricao | null;
  pecasSelecionadas: Peca[];
  maoDeObra: MaoDeObra[]; // Removido valor, só descrição e quantidade
  previsaoEntrega: string;
  
  // Metadata
  status: RepairStatus;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
}

export interface TermoGarantiaConfig {
  objetoGarantia: string;
  exclusoes: string[];
}

// Frases prontas para defeito relatado
export interface FrasePronta {
  id: string;
  texto: string;
}

export interface PecaCatalogo {
  codigo: string;
  descricao: string;
}

// Tipos de serviço de análise técnica
export interface TipoServicoAnalise {
  id: string;
  titulo: string;
  descricaoPadrao: string;
}

export interface StatusConfig {
  id: RepairStatus;
  label: string;
  order: number;
  color: string;
}

export interface FieldConfig {
  name: string;
  label: string;
  required: boolean;
  stage: 'entrada' | 'analise';
}

export const PECAS_CATALOGO: PecaCatalogo[] = [
  { codigo: 'PEC-001', descricao: 'Selo Mecânico' },
  { codigo: 'PEC-002', descricao: 'Rolamento 6205' },
  { codigo: 'PEC-003', descricao: 'Rolamento 6206' },
  { codigo: 'PEC-004', descricao: 'Rotor' },
  { codigo: 'PEC-005', descricao: 'Difusor' },
  { codigo: 'PEC-006', descricao: 'Eixo' },
  { codigo: 'PEC-007', descricao: 'Carcaça' },
  { codigo: 'PEC-008', descricao: 'Tampa Traseira' },
  { codigo: 'PEC-009', descricao: 'Tampa Dianteira' },
  { codigo: 'PEC-010', descricao: 'Flange de Sucção' },
  { codigo: 'PEC-011', descricao: 'Flange de Recalque' },
  { codigo: 'PEC-012', descricao: 'Junta de Vedação' },
  { codigo: 'PEC-013', descricao: 'O-Ring' },
  { codigo: 'PEC-014', descricao: 'Bucha de Desgaste' },
  { codigo: 'PEC-015', descricao: 'Capacitor' },
  { codigo: 'PEC-016', descricao: 'Bobina do Motor' },
  { codigo: 'PEC-017', descricao: 'Ventilador' },
  { codigo: 'PEC-018', descricao: 'Tampa do Ventilador' },
  { codigo: 'PEC-019', descricao: 'Parafusos e Porcas' },
  { codigo: 'PEC-020', descricao: 'Kit Reparo Completo' },
];

export const DEFAULT_FABRICANTES = [
  'Schneider',
  'Dancor',
  'KSB',
  'Thebe',
  'Franklin Electric',
  'Leão',
  'Imbil',
  'Jacuzzi',
  'Somar',
  'Famac',
  'Grundfos',
  'WEG',
];

export const DEFAULT_FRASES_DEFEITO: FrasePronta[] = [
  { id: '1', texto: 'Equipamento não liga' },
  { id: '2', texto: 'Baixa pressão de bombeamento' },
  { id: '3', texto: 'Vazamento pelo selo mecânico' },
  { id: '4', texto: 'Ruído anormal durante operação' },
  { id: '5', texto: 'Superaquecimento do motor' },
  { id: '6', texto: 'Vibração excessiva' },
  { id: '7', texto: 'Motor travado / não gira' },
  { id: '8', texto: 'Queima frequente do motor' },
  { id: '9', texto: 'Perda de vazão' },
  { id: '10', texto: 'Equipamento desarma pelo térmico' },
];

export const DEFAULT_TIPOS_SERVICO: TipoServicoAnalise[] = [
  { 
    id: '1', 
    titulo: 'Conjunto Hidráulico (Bombeador)', 
    descricaoPadrao: 'Constatou-se um alto índice de desgaste abrasivo/mecânico nos elementos internos. É imprescindível a substituição do Kit Chamber, que compreende os rotores, buchas, estágios e eixo, para restabelecer a volumetria e pressão do sistema.'
  },
  { 
    id: '2', 
    titulo: 'Sistema de Vedação', 
    descricaoPadrao: 'O selo mecânico apresenta sinais claros de desgaste em suas faces de contato. Além disso, foi detectada a ausência de peças de fixação essenciais para a montagem estanque do conjunto, que não acompanharam o equipamento no recebimento.'
  },
  { 
    id: '3', 
    titulo: 'Unidade Motora', 
    descricaoPadrao: 'Com foco na manutenção preventiva e longevidade do motor, identificou-se a necessidade de substituição dos rolamentos e a realização do processo de rejuvenescimento (limpeza técnica, secagem e aplicação de verniz isolante), visando garantir a integridade elétrica e mecânica do motor.'
  },
  { 
    id: '4', 
    titulo: 'Sistema Elétrico', 
    descricaoPadrao: 'Verificou-se comprometimento na isolação do enrolamento do motor, necessitando de rebobinamento completo ou substituição do estator.'
  },
  { 
    id: '5', 
    titulo: 'Componentes Mecânicos', 
    descricaoPadrao: 'Identificado desgaste nos componentes mecânicos de transmissão, necessitando substituição para garantir o funcionamento adequado do equipamento.'
  },
];

export const DEFAULT_STATUS_CONFIG: StatusConfig[] = [
  { id: 'entrada', label: 'Entrada (Triagem)', order: 1, color: '#3B82F6' },
  { id: 'analise', label: 'Em Análise', order: 2, color: '#F59E0B' },
  { id: 'concluido', label: 'Concluído', order: 3, color: '#00A651' },
];
