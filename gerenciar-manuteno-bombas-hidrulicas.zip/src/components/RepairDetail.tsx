import { useApp } from '../context/AppContext';
import { RepairOrder } from '../types';
import { 
  ArrowLeft, 
  Edit, 
  Trash2, 
  Calendar,
  User,
  Package,
  Wrench,
  Camera
} from 'lucide-react';

interface RepairDetailProps {
  order: RepairOrder;
  onClose: () => void;
  onEdit: (order: RepairOrder) => void;
}

export function RepairDetail({ order, onClose, onEdit }: RepairDetailProps) {
  const { deleteRepairOrder, statusConfig, currentUser } = useApp();

  const canEdit = currentUser?.permissions?.canEditOrders ?? false;
  const canDelete = currentUser?.permissions?.canDeleteOrders ?? false;

  const getStatusLabel = (status: string) => {
    const config = statusConfig.find(s => s.id === status);
    return config?.label || status;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'entrada': return 'bg-blue-100 text-blue-700';
      case 'analise': return 'bg-yellow-100 text-yellow-700';
      case 'concluido': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const handleDelete = () => {
    if (confirm('Tem certeza que deseja excluir esta ordem de serviço?')) {
      deleteRepairOrder(order.id);
      onClose();
    }
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 md:gap-4">
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <ArrowLeft className="w-5 h-5 md:w-6 md:h-6 text-gray-600" />
          </button>
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-[#003366]">
              TG: {order.numeroTG}
            </h2>
            <p className="text-sm text-gray-500">OS: {order.numeroOS}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {canEdit && (
            <button
              onClick={() => onEdit(order)}
              className="flex items-center gap-1 md:gap-2 px-3 md:px-4 py-2 text-[#003366] border border-[#003366] rounded-lg hover:bg-[#003366] hover:text-white transition text-sm"
            >
              <Edit className="w-4 h-4" />
              <span className="hidden sm:inline">Editar</span>
            </button>
          )}
          {canDelete && (
            <button
              onClick={handleDelete}
              className="flex items-center gap-1 md:gap-2 px-3 md:px-4 py-2 text-red-600 border border-red-600 rounded-lg hover:bg-red-600 hover:text-white transition text-sm"
            >
              <Trash2 className="w-4 h-4" />
              <span className="hidden sm:inline">Excluir</span>
            </button>
          )}
        </div>
      </div>

      {/* Status Badge */}
      <div className="flex items-center gap-3">
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
          {getStatusLabel(order.status)}
        </span>
        <span className="text-sm text-gray-500">
          Criado em {new Date(order.createdAt).toLocaleDateString('pt-BR')}
        </span>
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Cliente */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <div className="flex items-center gap-2 mb-4">
            <User className="w-5 h-5 text-[#00A651]" />
            <h3 className="font-semibold text-[#003366]">Dados do Cliente</h3>
          </div>
          <div className="space-y-3 text-sm">
            <div>
              <span className="text-gray-500">Código Entidade:</span>
              <p className="font-medium">{order.codigoEntidade}</p>
            </div>
            <div>
              <span className="text-gray-500">Nome:</span>
              <p className="font-medium">{order.nomeCliente}</p>
            </div>
            <div>
              <span className="text-gray-500">Vendedor:</span>
              <p className="font-medium">{order.vendedorResponsavel}</p>
            </div>
            {order.classeReceitaDespesa && (
              <div>
                <span className="text-gray-500">Classe Receita/Despesa:</span>
                <p className="font-medium">{order.classeReceitaDespesa}</p>
              </div>
            )}
          </div>
        </div>

        {/* Equipamento */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <div className="flex items-center gap-2 mb-4">
            <Package className="w-5 h-5 text-[#00A651]" />
            <h3 className="font-semibold text-[#003366]">Equipamento</h3>
          </div>
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-gray-500">Fabricante:</span>
                <p className="font-medium">{order.fabricante}</p>
              </div>
              <div>
                <span className="text-gray-500">Modelo:</span>
                <p className="font-medium">{order.modelo}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {order.potencia && (
                <div>
                  <span className="text-gray-500">Potência:</span>
                  <p className="font-medium">{order.potencia}</p>
                </div>
              )}
              {order.tensao && (
                <div>
                  <span className="text-gray-500">Tensão:</span>
                  <p className="font-medium">{order.tensao}</p>
                </div>
              )}
            </div>
            {order.tipoFase && (
              <div>
                <span className="text-gray-500">Tipo:</span>
                <p className="font-medium">{order.tipoFase === 'trifasico' ? 'Trifásico' : 'Monofásico'}</p>
              </div>
            )}
            <div>
              <span className="text-gray-500">Veio com conexões:</span>
              <p className="font-medium">{order.veioComConexoes === true ? 'Sim' : order.veioComConexoes === false ? 'Não' : 'Não informado'}</p>
            </div>
          </div>
        </div>

        {/* Defeito Relatado */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 lg:col-span-2">
          <h3 className="font-semibold text-[#003366] mb-3">Defeito Relatado</h3>
          <p className="text-gray-700 bg-orange-50 p-3 rounded-lg whitespace-pre-wrap">{order.defeitoRelatado || 'Não informado'}</p>
        </div>

        {/* Análise Técnica em Bancada */}
        {order.analiseTecnica && order.analiseTecnica.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Wrench className="w-5 h-5 text-[#00A651]" />
              <h3 className="font-semibold text-[#003366]">ANÁLISE TÉCNICA EM BANCADA</h3>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
              <p className="text-sm text-blue-800">
                Após o processo de desmontagem e avaliação minuciosa de cada componente em ambiente controlado, 
                foram identificadas as seguintes irregularidades:
              </p>
            </div>
            <div className="space-y-4">
              {order.analiseTecnica.map((item, idx) => (
                <div key={item.id || idx} className="border-l-4 border-[#00A651] pl-4 py-2">
                  <h4 className="font-semibold text-[#003366] mb-1">{item.titulo}</h4>
                  <p className="text-gray-700 text-sm">{item.descricao}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Conclusão e Recomendação */}
        {order.conclusaoRecomendacao && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 lg:col-span-2">
            <h3 className="font-semibold text-[#003366] mb-3">CONCLUSÃO E RECOMENDAÇÃO</h3>
            <p className="text-gray-700 bg-green-50 p-3 rounded-lg whitespace-pre-wrap">{order.conclusaoRecomendacao}</p>
          </div>
        )}

        {/* Mecânico */}
        {order.mecanicoResponsavel && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
            <h3 className="font-semibold text-[#003366] mb-3">Mecânico Responsável</h3>
            <p className="text-gray-700 font-medium">{order.mecanicoResponsavel}</p>
          </div>
        )}

        {/* Previsão de Entrega */}
        {order.previsaoEntrega && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-5 h-5 text-[#00A651]" />
              <h3 className="font-semibold text-[#003366]">Previsão de Entrega</h3>
            </div>
            <p className="text-lg font-medium text-[#003366]">
              {new Date(order.previsaoEntrega).toLocaleDateString('pt-BR')}
            </p>
          </div>
        )}

        {/* Peças */}
        {order.pecasSelecionadas && order.pecasSelecionadas.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 lg:col-span-2">
            <h3 className="font-semibold text-[#003366] mb-4">Peças a Serem Trocadas</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[300px]">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-3 py-2 font-medium">Código</th>
                    <th className="text-left px-3 py-2 font-medium">Descrição</th>
                    <th className="text-center px-3 py-2 font-medium">Qtd</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {order.pecasSelecionadas.map(peca => (
                    <tr key={peca.id}>
                      <td className="px-3 py-2 font-medium text-[#003366]">{peca.codigo}</td>
                      <td className="px-3 py-2">{peca.descricao}</td>
                      <td className="px-3 py-2 text-center">{peca.quantidade}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Mão de Obra / Serviços */}
        {order.maoDeObra && order.maoDeObra.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 lg:col-span-2">
            <h3 className="font-semibold text-[#003366] mb-4">Mão de Obra / Serviços</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[200px]">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-3 py-2 font-medium">Descrição</th>
                    <th className="text-center px-3 py-2 font-medium">Qtd</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {order.maoDeObra.map(mao => (
                    <tr key={mao.id}>
                      <td className="px-3 py-2">{mao.descricao}</td>
                      <td className="px-3 py-2 text-center">{mao.quantidade}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Fotos de Entrada */}
        {order.fotosEntrada && order.fotosEntrada.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Camera className="w-5 h-5 text-[#00A651]" />
              <h3 className="font-semibold text-[#003366]">Fotos da Entrada</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {order.fotosEntrada.map((foto, idx) => (
                <div key={idx} className="relative">
                  <img 
                    src={foto.url} 
                    alt={foto.descricao || `Foto ${idx + 1}`} 
                    className="w-full h-28 md:h-32 object-cover rounded-lg border" 
                  />
                  {foto.descricao && (
                    <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 rounded-b-lg truncate">
                      {foto.descricao}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Fotos de Análise */}
        {order.fotosAnalise && order.fotosAnalise.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Camera className="w-5 h-5 text-[#00A651]" />
              <h3 className="font-semibold text-[#003366]">Galeria Técnica</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {order.fotosAnalise.map((foto, idx) => (
                <div key={idx} className="relative">
                  <img 
                    src={foto.url} 
                    alt={foto.descricao || `Foto ${idx + 1}`} 
                    className="w-full h-28 md:h-32 object-cover rounded-lg border" 
                  />
                  {foto.descricao && (
                    <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 rounded-b-lg truncate">
                      {foto.descricao}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Plaquetas */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 lg:col-span-2">
          <h3 className="font-semibold text-[#003366] mb-4">Plaquetas de Identificação</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500 mb-2">Plaqueta da Bomba</p>
              {order.fotoPlaquetaBomba ? (
                <div className="relative">
                  <img 
                    src={order.fotoPlaquetaBomba.url} 
                    alt="Plaqueta Bomba" 
                    className="w-full h-36 md:h-40 object-contain rounded-lg border bg-gray-50" 
                  />
                  {order.fotoPlaquetaBomba.descricao && (
                    <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 rounded-b-lg truncate">
                      {order.fotoPlaquetaBomba.descricao}
                    </div>
                  )}
                </div>
              ) : (
                <div className="h-36 md:h-40 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
                  Não disponível
                </div>
              )}
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-2">Plaqueta do Motor</p>
              {order.fotoPlaquetaMotor ? (
                <div className="relative">
                  <img 
                    src={order.fotoPlaquetaMotor.url} 
                    alt="Plaqueta Motor" 
                    className="w-full h-36 md:h-40 object-contain rounded-lg border bg-gray-50" 
                  />
                  {order.fotoPlaquetaMotor.descricao && (
                    <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 rounded-b-lg truncate">
                      {order.fotoPlaquetaMotor.descricao}
                    </div>
                  )}
                </div>
              ) : (
                <div className="h-36 md:h-40 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
                  Não disponível
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Status Footer */}
      {order.status === 'concluido' && (
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 md:p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h4 className="font-semibold text-green-800">Análise Concluída</h4>
              <p className="text-sm text-green-600">Vendedor: {order.vendedorResponsavel}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
