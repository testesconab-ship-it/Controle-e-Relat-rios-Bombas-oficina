import { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { RepairOrder, RepairStatus, PECAS_CATALOGO, Peca, MaoDeObra, FotoComDescricao, AnaliseItem } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { 
  ArrowLeft, 
  Save, 
  Camera, 
  X, 
  Plus,
  ChevronRight,
  Edit,
  Trash2,
  ChevronDown
} from 'lucide-react';

interface RepairFormProps {
  order: RepairOrder | null;
  onClose: () => void;
}

export function RepairForm({ order, onClose }: RepairFormProps) {
  const { addRepairOrder, updateRepairOrder, fieldConfig, fabricantes, addFabricante, frasesDefeito, tiposServico } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [currentPhotoField, setCurrentPhotoField] = useState<string>('');
  const [newFabricante, setNewFabricante] = useState('');
  const [showAddFabricante, setShowAddFabricante] = useState(false);
  const [editingPecaId, setEditingPecaId] = useState<string | null>(null);
  const [editingMaoDeObraId, setEditingMaoDeObraId] = useState<string | null>(null);
  const [editingAnaliseId, setEditingAnaliseId] = useState<string | null>(null);
  const [pendingPhotoDescription, setPendingPhotoDescription] = useState('');
  const [pendingPhotoUrl, setPendingPhotoUrl] = useState<string | null>(null);
  const [showDefeitoDropdown, setShowDefeitoDropdown] = useState(false);
  const [showTipoServicoDropdown, setShowTipoServicoDropdown] = useState(false);
  
  // New piece form
  const [newPeca, setNewPeca] = useState({ codigo: '', descricao: '', quantidade: 1 });
  const [newMaoDeObra, setNewMaoDeObra] = useState({ descricao: '', quantidade: 1 });
  const [newAnalise, setNewAnalise] = useState({ titulo: '', descricao: '' });
  
  const [formData, setFormData] = useState({
    // Etapa 1
    codigoEntidade: order?.codigoEntidade || '',
    nomeCliente: order?.nomeCliente || '',
    numeroOS: order?.numeroOS || '',
    numeroTG: order?.numeroTG || '',
    vendedorResponsavel: order?.vendedorResponsavel || '',
    classeReceitaDespesa: order?.classeReceitaDespesa || '',
    fabricante: order?.fabricante || '',
    modelo: order?.modelo || '',
    potencia: order?.potencia || '',
    tensao: order?.tensao || '',
    tipoFase: order?.tipoFase || '' as '' | 'trifasico' | 'monofasico',
    defeitoRelatado: order?.defeitoRelatado || '',
    veioComConexoes: order?.veioComConexoes ?? null,
    fotosEntrada: order?.fotosEntrada || [] as FotoComDescricao[],
    
    // Etapa 2
    mecanicoResponsavel: order?.mecanicoResponsavel || '',
    analiseTecnica: order?.analiseTecnica || [] as AnaliseItem[],
    conclusaoRecomendacao: order?.conclusaoRecomendacao || '',
    fotosAnalise: order?.fotosAnalise || [] as FotoComDescricao[],
    fotoPlaquetaBomba: order?.fotoPlaquetaBomba || null as FotoComDescricao | null,
    fotoPlaquetaMotor: order?.fotoPlaquetaMotor || null as FotoComDescricao | null,
    pecasSelecionadas: order?.pecasSelecionadas || [] as Peca[],
    maoDeObra: order?.maoDeObra || [] as MaoDeObra[],
    previsaoEntrega: order?.previsaoEntrega || '',
    
    status: order?.status || 'entrada' as RepairStatus,
  });

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(
    order?.status === 'concluido' ? 3 : 
    order?.status === 'analise' ? 2 : 1
  );

  const isFieldRequired = (fieldName: string) => {
    const config = fieldConfig.find(f => f.name === fieldName);
    return config?.required || false;
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const file = files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      setPendingPhotoUrl(base64);
      setPendingPhotoDescription('');
    };
    reader.readAsDataURL(file);
  };

  const confirmPhotoWithDescription = () => {
    if (!pendingPhotoUrl) return;
    
    const newPhoto: FotoComDescricao = {
      url: pendingPhotoUrl,
      descricao: pendingPhotoDescription
    };

    if (currentPhotoField === 'fotosEntrada') {
      setFormData(prev => ({
        ...prev,
        fotosEntrada: [...prev.fotosEntrada, newPhoto].slice(0, 15)
      }));
    } else if (currentPhotoField === 'fotosAnalise') {
      setFormData(prev => ({
        ...prev,
        fotosAnalise: [...prev.fotosAnalise, newPhoto].slice(0, 15)
      }));
    } else if (currentPhotoField === 'fotoPlaquetaBomba') {
      setFormData(prev => ({ ...prev, fotoPlaquetaBomba: newPhoto }));
    } else if (currentPhotoField === 'fotoPlaquetaMotor') {
      setFormData(prev => ({ ...prev, fotoPlaquetaMotor: newPhoto }));
    }

    setPendingPhotoUrl(null);
    setPendingPhotoDescription('');
  };

  const removePhoto = (field: string, index?: number) => {
    if (field === 'fotosEntrada' && typeof index === 'number') {
      setFormData(prev => ({
        ...prev,
        fotosEntrada: prev.fotosEntrada.filter((_, i) => i !== index)
      }));
    } else if (field === 'fotosAnalise' && typeof index === 'number') {
      setFormData(prev => ({
        ...prev,
        fotosAnalise: prev.fotosAnalise.filter((_, i) => i !== index)
      }));
    } else if (field === 'fotoPlaquetaBomba') {
      setFormData(prev => ({ ...prev, fotoPlaquetaBomba: null }));
    } else if (field === 'fotoPlaquetaMotor') {
      setFormData(prev => ({ ...prev, fotoPlaquetaMotor: null }));
    }
  };

  const openFileDialog = (field: string) => {
    setCurrentPhotoField(field);
    fileInputRef.current?.click();
  };

  // Análise Técnica em Bancada
  const addAnaliseItem = () => {
    if (!newAnalise.titulo || !newAnalise.descricao) return;
    
    const item: AnaliseItem = {
      id: uuidv4(),
      titulo: newAnalise.titulo,
      descricao: newAnalise.descricao
    };
    
    setFormData(prev => ({
      ...prev,
      analiseTecnica: [...prev.analiseTecnica, item]
    }));
    setNewAnalise({ titulo: '', descricao: '' });
  };

  const addAnaliseFromTemplate = (tipo: { titulo: string; descricaoPadrao: string }) => {
    const item: AnaliseItem = {
      id: uuidv4(),
      titulo: tipo.titulo,
      descricao: tipo.descricaoPadrao
    };
    
    setFormData(prev => ({
      ...prev,
      analiseTecnica: [...prev.analiseTecnica, item]
    }));
    setShowTipoServicoDropdown(false);
  };

  const updateAnaliseItem = (id: string, updates: Partial<AnaliseItem>) => {
    setFormData(prev => ({
      ...prev,
      analiseTecnica: prev.analiseTecnica.map(a => 
        a.id === id ? { ...a, ...updates } : a
      )
    }));
  };

  const removeAnaliseItem = (id: string) => {
    setFormData(prev => ({
      ...prev,
      analiseTecnica: prev.analiseTecnica.filter(a => a.id !== id)
    }));
  };

  const addPeca = () => {
    if (!newPeca.codigo || !newPeca.descricao) return;
    
    const peca: Peca = {
      id: uuidv4(),
      codigo: newPeca.codigo,
      descricao: newPeca.descricao,
      quantidade: newPeca.quantidade
    };
    
    setFormData(prev => ({
      ...prev,
      pecasSelecionadas: [...prev.pecasSelecionadas, peca]
    }));
    setNewPeca({ codigo: '', descricao: '', quantidade: 1 });
  };

  const addPecaFromCatalog = (pecaCatalogo: { codigo: string; descricao: string }) => {
    const peca: Peca = {
      id: uuidv4(),
      codigo: pecaCatalogo.codigo,
      descricao: pecaCatalogo.descricao,
      quantidade: 1
    };
    
    setFormData(prev => ({
      ...prev,
      pecasSelecionadas: [...prev.pecasSelecionadas, peca]
    }));
  };

  const updatePeca = (id: string, updates: Partial<Peca>) => {
    setFormData(prev => ({
      ...prev,
      pecasSelecionadas: prev.pecasSelecionadas.map(p => 
        p.id === id ? { ...p, ...updates } : p
      )
    }));
  };

  const removePeca = (id: string) => {
    setFormData(prev => ({
      ...prev,
      pecasSelecionadas: prev.pecasSelecionadas.filter(p => p.id !== id)
    }));
  };

  const addMaoDeObraItem = () => {
    if (!newMaoDeObra.descricao) return;
    
    const mao: MaoDeObra = {
      id: uuidv4(),
      descricao: newMaoDeObra.descricao,
      quantidade: newMaoDeObra.quantidade
    };
    
    setFormData(prev => ({
      ...prev,
      maoDeObra: [...prev.maoDeObra, mao]
    }));
    setNewMaoDeObra({ descricao: '', quantidade: 1 });
  };

  const updateMaoDeObra = (id: string, updates: Partial<MaoDeObra>) => {
    setFormData(prev => ({
      ...prev,
      maoDeObra: prev.maoDeObra.map(m => 
        m.id === id ? { ...m, ...updates } : m
      )
    }));
  };

  const removeMaoDeObra = (id: string) => {
    setFormData(prev => ({
      ...prev,
      maoDeObra: prev.maoDeObra.filter(m => m.id !== id)
    }));
  };

  const handleAddFabricante = () => {
    if (newFabricante.trim()) {
      addFabricante(newFabricante.trim());
      setFormData(prev => ({ ...prev, fabricante: newFabricante.trim() }));
      setNewFabricante('');
      setShowAddFabricante(false);
    }
  };

  const handleSubmit = () => {
    const status: RepairStatus = 
      currentStep === 3 ? 'concluido' :
      currentStep === 2 ? 'analise' : 'entrada';

    const orderData = {
      ...formData,
      status,
    };

    if (order) {
      updateRepairOrder(order.id, orderData);
    } else {
      addRepairOrder(orderData);
    }
    
    onClose();
  };

  const advanceStep = () => {
    if (currentStep < 3) {
      setCurrentStep((currentStep + 1) as 1 | 2 | 3);
    }
  };

  return (
    <div className="space-y-4 md:space-y-6">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handlePhotoUpload}
        className="hidden"
      />

      {/* Photo Description Modal */}
      {pendingPhotoUrl && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full p-4 md:p-6">
            <h3 className="font-semibold text-[#003366] mb-4">Adicionar Descrição à Foto</h3>
            <div className="mb-4">
              <img src={pendingPhotoUrl} alt="Preview" className="w-full h-48 object-contain rounded-lg bg-gray-100" />
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Descrição da Foto
              </label>
              <textarea
                value={pendingPhotoDescription}
                onChange={(e) => setPendingPhotoDescription(e.target.value)}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
                placeholder="Descreva o que a foto mostra..."
                rows={3}
              />
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => { setPendingPhotoUrl(null); setPendingPhotoDescription(''); }}
                className="flex-1 px-4 py-2 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition"
              >
                Cancelar
              </button>
              <button
                onClick={confirmPhotoWithDescription}
                className="flex-1 px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-3 md:gap-4">
        <button
          onClick={onClose}
          className="p-2 hover:bg-gray-100 rounded-lg transition"
        >
          <ArrowLeft className="w-5 h-5 md:w-6 md:h-6 text-gray-600" />
        </button>
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-[#003366]">
            {order ? 'Editar Ordem de Serviço' : 'Nova Entrada'}
          </h2>
          <p className="text-sm text-gray-500">Preencha os dados do equipamento</p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-center gap-1 md:gap-2 overflow-x-auto pb-2">
        {[1, 2, 3].map(step => (
          <button
            key={step}
            onClick={() => setCurrentStep(step as 1 | 2 | 3)}
            className={`flex items-center gap-1 md:gap-2 px-3 md:px-4 py-2 rounded-lg font-medium transition whitespace-nowrap ${
              currentStep === step
                ? 'bg-[#003366] text-white'
                : currentStep > step
                ? 'bg-green-100 text-green-700'
                : 'bg-gray-100 text-gray-500'
            }`}
          >
            <span className="w-5 h-5 md:w-6 md:h-6 rounded-full bg-white/20 flex items-center justify-center text-xs md:text-sm">
              {step}
            </span>
            <span className="text-xs md:text-sm">
              {step === 1 && 'Entrada'}
              {step === 2 && 'Análise'}
              {step === 3 && 'Concluído'}
            </span>
          </button>
        ))}
      </div>

      {/* Form Content */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
        {/* Step 1: Entrada */}
        {currentStep === 1 && (
          <div className="space-y-4 md:space-y-6">
            <h3 className="text-lg font-semibold text-[#003366] border-b pb-2">
              Etapa 1: Entrada (Triagem)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Código Entidade (ID) {isFieldRequired('codigoEntidade') && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="text"
                  value={formData.codigoEntidade}
                  onChange={(e) => setFormData(prev => ({ ...prev, codigoEntidade: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                  placeholder="Ex: CLI-001"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nome do Cliente {isFieldRequired('nomeCliente') && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="text"
                  value={formData.nomeCliente}
                  onChange={(e) => setFormData(prev => ({ ...prev, nomeCliente: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                  placeholder="Nome completo"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Número da OS {isFieldRequired('numeroOS') && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="text"
                  value={formData.numeroOS}
                  onChange={(e) => setFormData(prev => ({ ...prev, numeroOS: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                  placeholder="Ex: OS-2024-001"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Número do TG {isFieldRequired('numeroTG') && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="text"
                  value={formData.numeroTG}
                  onChange={(e) => setFormData(prev => ({ ...prev, numeroTG: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                  placeholder="Ex: TG-001"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Vendedor Responsável {isFieldRequired('vendedorResponsavel') && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="text"
                  value={formData.vendedorResponsavel}
                  onChange={(e) => setFormData(prev => ({ ...prev, vendedorResponsavel: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                  placeholder="Nome do vendedor"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Classe Receita/Despesa (Rateio)
                </label>
                <input
                  type="text"
                  value={formData.classeReceitaDespesa}
                  onChange={(e) => setFormData(prev => ({ ...prev, classeReceitaDespesa: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                  placeholder="Ex: 1.1.01"
                />
              </div>
            </div>

            {/* Equipamento */}
            <div className="border-t pt-4">
              <h4 className="text-md font-semibold text-[#003366] mb-4">Dados do Equipamento</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Fabricante {isFieldRequired('fabricante') && <span className="text-red-500">*</span>}
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={formData.fabricante}
                      onChange={(e) => {
                        if (e.target.value === '__add__') {
                          setShowAddFabricante(true);
                        } else {
                          setFormData(prev => ({ ...prev, fabricante: e.target.value }));
                        }
                      }}
                      className="flex-1 px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent bg-white text-base"
                    >
                      <option value="">Selecione o fabricante</option>
                      {fabricantes.map((fab: string) => (
                        <option key={fab} value={fab}>{fab}</option>
                      ))}
                      <option value="__add__">+ Adicionar novo fabricante</option>
                    </select>
                  </div>
                  {showAddFabricante && (
                    <div className="mt-2 flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={newFabricante}
                        onChange={(e) => setNewFabricante(e.target.value)}
                        className="flex-1 px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
                        placeholder="Nome do novo fabricante"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={handleAddFabricante}
                          className="flex-1 sm:flex-none px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition"
                        >
                          Adicionar
                        </button>
                        <button
                          onClick={() => { setShowAddFabricante(false); setNewFabricante(''); }}
                          className="flex-1 sm:flex-none px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Modelo {isFieldRequired('modelo') && <span className="text-red-500">*</span>}
                  </label>
                  <input
                    type="text"
                    value={formData.modelo}
                    onChange={(e) => setFormData(prev => ({ ...prev, modelo: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                    placeholder="Ex: CR32-8 A-F-A-E-HQQE"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Potência
                  </label>
                  <input
                    type="text"
                    value={formData.potencia}
                    onChange={(e) => setFormData(prev => ({ ...prev, potencia: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                    placeholder="Ex: 40,0 CV IR3"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tensão
                  </label>
                  <input
                    type="text"
                    value={formData.tensao}
                    onChange={(e) => setFormData(prev => ({ ...prev, tensao: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                    placeholder="Ex: 220/380/440 V"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tipo de Fase
                  </label>
                  <select
                    value={formData.tipoFase}
                    onChange={(e) => setFormData(prev => ({ ...prev, tipoFase: e.target.value as '' | 'trifasico' | 'monofasico' }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent bg-white text-base"
                  >
                    <option value="">Selecione</option>
                    <option value="trifasico">Trifásico</option>
                    <option value="monofasico">Monofásico</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Veio com conexões?
                  </label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        checked={formData.veioComConexoes === true}
                        onChange={() => setFormData(prev => ({ ...prev, veioComConexoes: true }))}
                        className="w-5 h-5 text-[#00A651]"
                      />
                      <span>Sim</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        checked={formData.veioComConexoes === false}
                        onChange={() => setFormData(prev => ({ ...prev, veioComConexoes: false }))}
                        className="w-5 h-5 text-[#00A651]"
                      />
                      <span>Não</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Defeito Relatado com Dropdown */}
            <div className="relative">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Defeito Relatado {isFieldRequired('defeitoRelatado') && <span className="text-red-500">*</span>}
              </label>
              <div className="relative">
                <textarea
                  value={formData.defeitoRelatado}
                  onChange={(e) => setFormData(prev => ({ ...prev, defeitoRelatado: e.target.value }))}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                  placeholder="Descreva o defeito relatado pelo cliente..."
                />
                <button
                  type="button"
                  onClick={() => setShowDefeitoDropdown(!showDefeitoDropdown)}
                  className="absolute top-2 right-2 p-2 text-gray-400 hover:text-[#003366] hover:bg-gray-100 rounded-lg transition"
                  title="Selecionar frase pronta"
                >
                  <ChevronDown className="w-5 h-5" />
                </button>
              </div>
              
              {showDefeitoDropdown && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  <div className="p-2 border-b bg-gray-50">
                    <span className="text-xs font-medium text-gray-500">Frases Prontas</span>
                  </div>
                  {frasesDefeito.map(frase => (
                    <button
                      key={frase.id}
                      type="button"
                      onClick={() => {
                        setFormData(prev => ({
                          ...prev,
                          defeitoRelatado: prev.defeitoRelatado 
                            ? `${prev.defeitoRelatado}\n${frase.texto}`
                            : frase.texto
                        }));
                        setShowDefeitoDropdown(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-gray-50 border-b last:border-b-0 text-sm"
                    >
                      {frase.texto}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fotos do Equipamento na Entrada
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {formData.fotosEntrada.map((foto, idx) => (
                  <div key={idx} className="relative group">
                    <img src={foto.url} alt={`Foto ${idx + 1}`} className="w-full h-24 md:h-28 object-cover rounded-lg border" />
                    {foto.descricao && (
                      <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 rounded-b-lg truncate">
                        {foto.descricao}
                      </div>
                    )}
                    <button
                      onClick={() => removePhoto('fotosEntrada', idx)}
                      className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {formData.fotosEntrada.length < 15 && (
                  <button
                    onClick={() => openFileDialog('fotosEntrada')}
                    className="h-24 md:h-28 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:border-[#00A651] hover:text-[#00A651] transition"
                  >
                    <Camera className="w-6 h-6 md:w-8 md:h-8" />
                    <span className="text-xs mt-1">Adicionar</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Análise */}
        {currentStep === 2 && (
          <div className="space-y-4 md:space-y-6">
            <h3 className="text-lg font-semibold text-[#003366] border-b pb-2">
              Etapa 2: Análise
            </h3>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Mecânico Responsável pela Análise
              </label>
              <input
                type="text"
                value={formData.mecanicoResponsavel}
                onChange={(e) => setFormData(prev => ({ ...prev, mecanicoResponsavel: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                placeholder="Nome do mecânico"
              />
            </div>

            {/* ANÁLISE TÉCNICA EM BANCADA */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                ANÁLISE TÉCNICA EM BANCADA {isFieldRequired('analiseTecnica') && <span className="text-red-500">*</span>}
              </label>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                <p className="text-sm text-blue-800">
                  Após o processo de desmontagem e avaliação minuciosa de cada componente em ambiente controlado, 
                  foram identificadas as seguintes irregularidades:
                </p>
              </div>

              {/* Lista de itens de análise */}
              {formData.analiseTecnica.length > 0 && (
                <div className="space-y-3 mb-4">
                  {formData.analiseTecnica.map((item) => (
                    <div key={item.id} className="border rounded-lg p-4 bg-gray-50">
                      {editingAnaliseId === item.id ? (
                        <div className="space-y-3">
                          <input
                            type="text"
                            value={item.titulo}
                            onChange={(e) => updateAnaliseItem(item.id, { titulo: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg font-medium"
                            placeholder="Título do serviço"
                          />
                          <textarea
                            value={item.descricao}
                            onChange={(e) => updateAnaliseItem(item.id, { descricao: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg text-sm"
                            rows={4}
                            placeholder="Descrição detalhada"
                          />
                          <button
                            onClick={() => setEditingAnaliseId(null)}
                            className="px-4 py-2 bg-[#00A651] text-white rounded-lg text-sm hover:bg-[#008C44] transition"
                          >
                            Salvar
                          </button>
                        </div>
                      ) : (
                        <div>
                          <div className="flex items-start justify-between mb-2">
                            <h5 className="font-semibold text-[#003366]">{item.titulo}</h5>
                            <div className="flex gap-1">
                              <button
                                onClick={() => setEditingAnaliseId(item.id)}
                                className="p-1 text-blue-600 hover:bg-blue-100 rounded"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => removeAnaliseItem(item.id)}
                                className="p-1 text-red-600 hover:bg-red-100 rounded"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                          <p className="text-sm text-gray-700">{item.descricao}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Botão para adicionar do template */}
              <div className="relative mb-4">
                <button
                  type="button"
                  onClick={() => setShowTipoServicoDropdown(!showTipoServicoDropdown)}
                  className="w-full flex items-center justify-between px-4 py-3 border border-dashed border-[#00A651] text-[#00A651] rounded-lg hover:bg-green-50 transition"
                >
                  <span className="flex items-center gap-2">
                    <Plus className="w-5 h-5" />
                    Adicionar Item de Análise (Templates)
                  </span>
                  <ChevronDown className="w-5 h-5" />
                </button>
                
                {showTipoServicoDropdown && (
                  <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {tiposServico.map(tipo => (
                      <button
                        key={tipo.id}
                        type="button"
                        onClick={() => addAnaliseFromTemplate(tipo)}
                        className="w-full text-left px-4 py-3 hover:bg-gray-50 border-b last:border-b-0"
                      >
                        <div className="font-medium text-[#003366]">{tipo.titulo}</div>
                        <div className="text-xs text-gray-500 line-clamp-2">{tipo.descricaoPadrao}</div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Adicionar manualmente */}
              <div className="border rounded-lg p-4 bg-gray-50">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Adicionar Item Manualmente</h4>
                <div className="space-y-3">
                  <input
                    type="text"
                    value={newAnalise.titulo}
                    onChange={(e) => setNewAnalise(prev => ({ ...prev, titulo: e.target.value }))}
                    className="w-full px-3 py-2 border rounded-lg text-base"
                    placeholder="Título (Ex: Conjunto Hidráulico)"
                  />
                  <textarea
                    value={newAnalise.descricao}
                    onChange={(e) => setNewAnalise(prev => ({ ...prev, descricao: e.target.value }))}
                    className="w-full px-3 py-2 border rounded-lg text-base"
                    rows={3}
                    placeholder="Descrição detalhada da irregularidade encontrada..."
                  />
                  <button
                    onClick={addAnaliseItem}
                    className="px-4 py-2 bg-[#003366] text-white rounded-lg hover:bg-[#002244] transition flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Adicionar
                  </button>
                </div>
              </div>
            </div>

            {/* CONCLUSÃO E RECOMENDAÇÃO */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                CONCLUSÃO E RECOMENDAÇÃO
              </label>
              <textarea
                value={formData.conclusaoRecomendacao}
                onChange={(e) => setFormData(prev => ({ ...prev, conclusaoRecomendacao: e.target.value }))}
                rows={4}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
                placeholder="Descreva a conclusão técnica e recomendações..."
              />
            </div>

            {/* Fotos */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Galeria Técnica - Fotos das Peças (até 15 fotos)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {formData.fotosAnalise.map((foto, idx) => (
                  <div key={idx} className="relative group">
                    <img src={foto.url} alt={`Foto ${idx + 1}`} className="w-full h-24 md:h-28 object-cover rounded-lg border" />
                    {foto.descricao && (
                      <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 rounded-b-lg truncate">
                        {foto.descricao}
                      </div>
                    )}
                    <button
                      onClick={() => removePhoto('fotosAnalise', idx)}
                      className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {formData.fotosAnalise.length < 15 && (
                  <button
                    onClick={() => openFileDialog('fotosAnalise')}
                    className="h-24 md:h-28 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:border-[#00A651] hover:text-[#00A651] transition"
                  >
                    <Camera className="w-6 h-6 md:w-8 md:h-8" />
                    <span className="text-xs mt-1">Adicionar</span>
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Foto da Plaqueta da Bomba
                </label>
                {formData.fotoPlaquetaBomba ? (
                  <div className="relative group inline-block w-full">
                    <img src={formData.fotoPlaquetaBomba.url} alt="Plaqueta Bomba" className="w-full h-32 md:h-36 object-contain rounded-lg border bg-gray-50" />
                    {formData.fotoPlaquetaBomba.descricao && (
                      <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 rounded-b-lg truncate">
                        {formData.fotoPlaquetaBomba.descricao}
                      </div>
                    )}
                    <button
                      onClick={() => removePhoto('fotoPlaquetaBomba')}
                      className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => openFileDialog('fotoPlaquetaBomba')}
                    className="h-32 md:h-36 w-full border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:border-[#00A651] hover:text-[#00A651] transition"
                  >
                    <Camera className="w-8 h-8 md:w-10 md:h-10" />
                    <span className="text-sm mt-2">Foto Plaqueta Bomba</span>
                  </button>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Foto da Plaqueta do Motor
                </label>
                {formData.fotoPlaquetaMotor ? (
                  <div className="relative group inline-block w-full">
                    <img src={formData.fotoPlaquetaMotor.url} alt="Plaqueta Motor" className="w-full h-32 md:h-36 object-contain rounded-lg border bg-gray-50" />
                    {formData.fotoPlaquetaMotor.descricao && (
                      <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 rounded-b-lg truncate">
                        {formData.fotoPlaquetaMotor.descricao}
                      </div>
                    )}
                    <button
                      onClick={() => removePhoto('fotoPlaquetaMotor')}
                      className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => openFileDialog('fotoPlaquetaMotor')}
                    className="h-32 md:h-36 w-full border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:border-[#00A651] hover:text-[#00A651] transition"
                  >
                    <Camera className="w-8 h-8 md:w-10 md:h-10" />
                    <span className="text-sm mt-2">Foto Plaqueta Motor</span>
                  </button>
                )}
              </div>
            </div>

            {/* Peças a Serem Trocadas */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Peças a Serem Trocadas
              </label>
              
              {/* Lista de peças adicionadas */}
              {formData.pecasSelecionadas.length > 0 && (
                <div className="mb-4 border rounded-lg overflow-x-auto">
                  <table className="w-full text-sm min-w-[400px]">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium">Código</th>
                        <th className="text-left px-3 py-2 font-medium">Descrição</th>
                        <th className="text-center px-3 py-2 font-medium">Qtd</th>
                        <th className="text-center px-3 py-2 font-medium">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {formData.pecasSelecionadas.map(peca => (
                        <tr key={peca.id}>
                          {editingPecaId === peca.id ? (
                            <>
                              <td className="px-3 py-2">
                                <input
                                  type="text"
                                  value={peca.codigo}
                                  onChange={(e) => updatePeca(peca.id, { codigo: e.target.value })}
                                  className="w-full px-2 py-1 border rounded"
                                />
                              </td>
                              <td className="px-3 py-2">
                                <input
                                  type="text"
                                  value={peca.descricao}
                                  onChange={(e) => updatePeca(peca.id, { descricao: e.target.value })}
                                  className="w-full px-2 py-1 border rounded"
                                />
                              </td>
                              <td className="px-3 py-2">
                                <input
                                  type="number"
                                  min="1"
                                  value={peca.quantidade}
                                  onChange={(e) => updatePeca(peca.id, { quantidade: parseInt(e.target.value) || 1 })}
                                  className="w-16 px-2 py-1 border rounded text-center"
                                />
                              </td>
                              <td className="px-3 py-2 text-center">
                                <button
                                  onClick={() => setEditingPecaId(null)}
                                  className="text-green-600 hover:text-green-700 p-1"
                                >
                                  <Save className="w-4 h-4" />
                                </button>
                              </td>
                            </>
                          ) : (
                            <>
                              <td className="px-3 py-2 font-medium text-[#003366]">{peca.codigo}</td>
                              <td className="px-3 py-2">{peca.descricao}</td>
                              <td className="px-3 py-2 text-center">{peca.quantidade}</td>
                              <td className="px-3 py-2 text-center">
                                <button
                                  onClick={() => setEditingPecaId(peca.id)}
                                  className="text-blue-600 hover:text-blue-700 p-1"
                                >
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => removePeca(peca.id)}
                                  className="text-red-600 hover:text-red-700 p-1 ml-1"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Adicionar nova peça manualmente */}
              <div className="border rounded-lg p-4 bg-gray-50 mb-4">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Adicionar Peça Manualmente</h4>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <input
                    type="text"
                    value={newPeca.codigo}
                    onChange={(e) => setNewPeca(prev => ({ ...prev, codigo: e.target.value }))}
                    className="px-3 py-2 border rounded-lg"
                    placeholder="Código"
                  />
                  <input
                    type="text"
                    value={newPeca.descricao}
                    onChange={(e) => setNewPeca(prev => ({ ...prev, descricao: e.target.value }))}
                    className="px-3 py-2 border rounded-lg sm:col-span-2"
                    placeholder="Descrição"
                  />
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min="1"
                      value={newPeca.quantidade}
                      onChange={(e) => setNewPeca(prev => ({ ...prev, quantidade: parseInt(e.target.value) || 1 }))}
                      className="w-16 md:w-20 px-3 py-2 border rounded-lg"
                      placeholder="Qtd"
                    />
                    <button
                      onClick={addPeca}
                      className="flex-1 px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition flex items-center justify-center gap-1"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Catálogo de peças */}
              <div className="border rounded-lg max-h-40 md:max-h-48 overflow-y-auto">
                <div className="px-3 py-2 bg-gray-50 border-b font-medium text-sm text-gray-600 sticky top-0">
                  Ou selecione do catálogo
                </div>
                {PECAS_CATALOGO.map(peca => (
                  <button
                    key={peca.codigo}
                    onClick={() => addPecaFromCatalog(peca)}
                    className="w-full flex items-center justify-between px-4 py-2 hover:bg-gray-50 border-b last:border-b-0 text-left"
                  >
                    <span className="text-sm">
                      <strong className="text-[#003366]">{peca.codigo}</strong>
                      <span className="text-gray-600 ml-2">{peca.descricao}</span>
                    </span>
                    <Plus className="w-4 h-4 text-[#00A651] flex-shrink-0" />
                  </button>
                ))}
              </div>
            </div>

            {/* Mão de Obra / Serviços (sem valor) */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mão de Obra / Serviços
              </label>
              
              {/* Lista de mão de obra adicionada */}
              {formData.maoDeObra.length > 0 && (
                <div className="mb-4 border rounded-lg overflow-x-auto">
                  <table className="w-full text-sm min-w-[300px]">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium">Descrição</th>
                        <th className="text-center px-3 py-2 font-medium">Qtd</th>
                        <th className="text-center px-3 py-2 font-medium">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {formData.maoDeObra.map(mao => (
                        <tr key={mao.id}>
                          {editingMaoDeObraId === mao.id ? (
                            <>
                              <td className="px-3 py-2">
                                <input
                                  type="text"
                                  value={mao.descricao}
                                  onChange={(e) => updateMaoDeObra(mao.id, { descricao: e.target.value })}
                                  className="w-full px-2 py-1 border rounded"
                                />
                              </td>
                              <td className="px-3 py-2">
                                <input
                                  type="number"
                                  min="1"
                                  value={mao.quantidade}
                                  onChange={(e) => updateMaoDeObra(mao.id, { quantidade: parseInt(e.target.value) || 1 })}
                                  className="w-16 px-2 py-1 border rounded text-center"
                                />
                              </td>
                              <td className="px-3 py-2 text-center">
                                <button
                                  onClick={() => setEditingMaoDeObraId(null)}
                                  className="text-green-600 hover:text-green-700 p-1"
                                >
                                  <Save className="w-4 h-4" />
                                </button>
                              </td>
                            </>
                          ) : (
                            <>
                              <td className="px-3 py-2">{mao.descricao}</td>
                              <td className="px-3 py-2 text-center">{mao.quantidade}</td>
                              <td className="px-3 py-2 text-center">
                                <button
                                  onClick={() => setEditingMaoDeObraId(mao.id)}
                                  className="text-blue-600 hover:text-blue-700 p-1"
                                >
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => removeMaoDeObra(mao.id)}
                                  className="text-red-600 hover:text-red-700 p-1 ml-1"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Adicionar nova mão de obra */}
              <div className="border rounded-lg p-4 bg-gray-50">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Adicionar Mão de Obra / Serviço</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="text"
                    value={newMaoDeObra.descricao}
                    onChange={(e) => setNewMaoDeObra(prev => ({ ...prev, descricao: e.target.value }))}
                    className="px-3 py-2 border rounded-lg sm:col-span-2"
                    placeholder="Descrição do serviço"
                  />
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min="1"
                      value={newMaoDeObra.quantidade}
                      onChange={(e) => setNewMaoDeObra(prev => ({ ...prev, quantidade: parseInt(e.target.value) || 1 }))}
                      className="w-16 md:w-20 px-3 py-2 border rounded-lg"
                      placeholder="Qtd"
                    />
                    <button
                      onClick={addMaoDeObraItem}
                      className="flex-1 px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition flex items-center justify-center gap-1"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Previsão de Entrega {isFieldRequired('previsaoEntrega') && <span className="text-red-500">*</span>}
              </label>
              <input
                type="date"
                value={formData.previsaoEntrega}
                onChange={(e) => setFormData(prev => ({ ...prev, previsaoEntrega: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
              />
            </div>
          </div>
        )}

        {/* Step 3: Concluído */}
        {currentStep === 3 && (
          <div className="space-y-4 md:space-y-6">
            <h3 className="text-lg font-semibold text-[#003366] border-b pb-2">
              Etapa 3: Concluído
            </h3>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4 md:p-6 text-center">
              <div className="w-14 h-14 md:w-16 md:h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-7 h-7 md:w-8 md:h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h4 className="text-lg md:text-xl font-semibold text-green-800 mb-2">Análise Concluída!</h4>
              <p className="text-green-700 text-sm md:text-base">A análise técnica está pronta para ser enviada ao cliente.</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 md:p-6">
              <h4 className="font-semibold text-[#003366] mb-4">Resumo da Análise</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Cliente:</span>
                  <p className="font-medium">{formData.nomeCliente}</p>
                </div>
                <div>
                  <span className="text-gray-500">OS:</span>
                  <p className="font-medium">{formData.numeroOS}</p>
                </div>
                <div>
                  <span className="text-gray-500">Equipamento:</span>
                  <p className="font-medium">{formData.fabricante} - {formData.modelo}</p>
                </div>
                <div>
                  <span className="text-gray-500">Potência:</span>
                  <p className="font-medium">{formData.potencia || '-'}</p>
                </div>
                <div>
                  <span className="text-gray-500">Tensão:</span>
                  <p className="font-medium">{formData.tensao || '-'}</p>
                </div>
                <div>
                  <span className="text-gray-500">Tipo:</span>
                  <p className="font-medium">{formData.tipoFase === 'trifasico' ? 'Trifásico' : formData.tipoFase === 'monofasico' ? 'Monofásico' : '-'}</p>
                </div>
                <div>
                  <span className="text-gray-500">Previsão:</span>
                  <p className="font-medium">
                    {formData.previsaoEntrega ? new Date(formData.previsaoEntrega).toLocaleDateString('pt-BR') : '-'}
                  </p>
                </div>
                {formData.mecanicoResponsavel && (
                  <div>
                    <span className="text-gray-500">Mecânico:</span>
                    <p className="font-medium">{formData.mecanicoResponsavel}</p>
                  </div>
                )}
                <div className="col-span-1 sm:col-span-2">
                  <span className="text-gray-500">Itens de Análise ({formData.analiseTecnica.length}):</span>
                  {formData.analiseTecnica.map(item => (
                    <p key={item.id} className="font-medium text-[#003366]">• {item.titulo}</p>
                  ))}
                </div>
                <div className="col-span-1 sm:col-span-2">
                  <span className="text-gray-500">Peças ({formData.pecasSelecionadas.length}):</span>
                  <p className="font-medium">
                    {formData.pecasSelecionadas.map(p => `${p.descricao} (x${p.quantidade})`).join(', ') || 'Nenhuma peça selecionada'}
                  </p>
                </div>
                {formData.maoDeObra.length > 0 && (
                  <div className="col-span-1 sm:col-span-2">
                    <span className="text-gray-500">Serviços:</span>
                    <p className="font-medium">
                      {formData.maoDeObra.map(m => `${m.descricao} (x${m.quantidade})`).join(', ')}
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-800 mb-2">Vendedor Responsável</h4>
              <p className="text-blue-700 text-lg">{formData.vendedorResponsavel || 'Não informado'}</p>
              <p className="text-blue-600 text-sm mt-1">Entre em contato para finalizar</p>
            </div>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3 justify-end">
        {currentStep < 3 && (
          <button
            onClick={advanceStep}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-[#003366] text-white font-semibold rounded-lg hover:bg-[#002244] transition"
          >
            Avançar Etapa
            <ChevronRight className="w-5 h-5" />
          </button>
        )}
        <button
          onClick={handleSubmit}
          className="flex items-center justify-center gap-2 px-6 py-3 bg-[#00A651] text-white font-semibold rounded-lg hover:bg-[#008C44] transition shadow-lg"
        >
          <Save className="w-5 h-5" />
          Salvar
        </button>
      </div>
    </div>
  );
}
