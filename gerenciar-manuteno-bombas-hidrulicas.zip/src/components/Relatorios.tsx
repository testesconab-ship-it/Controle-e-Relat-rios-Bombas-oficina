import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RepairOrder } from '../types';
import { 
  Search, 
  FileText, 
  Filter,
  Download,
  Eye,
  X,
  Loader2,
  Settings
} from 'lucide-react';
import jsPDF from 'jspdf';

interface ExportOptions {
  identificacao: boolean;
  dadosCliente: boolean;
  equipamento: boolean;
  defeitoRelatado: boolean;
  analiseTecnica: boolean;
  fotos: boolean;
  pecas: boolean;
  servicos: boolean;
  conclusao: boolean;
  termoGarantia: boolean;
  assinaturas: boolean;
}

export function Relatorios() {
  const { repairOrders, statusConfig, fabricantes, termoGarantia, currentUser } = useApp();
  const [selectedOrder, setSelectedOrder] = useState<RepairOrder | null>(null);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [showExportOptions, setShowExportOptions] = useState(false);
  const [orderToExport, setOrderToExport] = useState<RepairOrder | null>(null);

  const canExportPDF = currentUser?.permissions?.canExportPDF ?? (currentUser?.role === 'admin');

  // Export Options State
  const [exportOptions, setExportOptions] = useState<ExportOptions>({
    identificacao: true,
    dadosCliente: true,
    equipamento: true,
    defeitoRelatado: true,
    analiseTecnica: true,
    fotos: true,
    pecas: true,
    servicos: true,
    conclusao: true,
    termoGarantia: true,
    assinaturas: true,
  });
  
  // Filters
  const [filters, setFilters] = useState({
    tg: '',
    codigoEntidade: '',
    os: '',
    fabricante: '',
    modelo: '',
  });

  const filteredOrders = repairOrders.filter(order => {
    return (
      (!filters.tg || order.numeroTG.toLowerCase().includes(filters.tg.toLowerCase())) &&
      (!filters.codigoEntidade || order.codigoEntidade.toLowerCase().includes(filters.codigoEntidade.toLowerCase())) &&
      (!filters.os || order.numeroOS.toLowerCase().includes(filters.os.toLowerCase())) &&
      (!filters.fabricante || order.fabricante === filters.fabricante) &&
      (!filters.modelo || order.modelo.toLowerCase().includes(filters.modelo.toLowerCase()))
    );
  });

  const getStatusLabel = (status: string) => {
    const config = statusConfig.find(s => s.id === status);
    return config?.label || status;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'entrada': return 'bg-blue-100 text-blue-700';
      case 'analise': return 'bg-yellow-100 text-yellow-700';
      case 'concluido': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const clearFilters = () => {
    setFilters({
      tg: '',
      codigoEntidade: '',
      os: '',
      fabricante: '',
      modelo: '',
    });
  };

  const toggleExportOption = (key: keyof ExportOptions) => {
    setExportOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const selectAllOptions = () => {
    setExportOptions({
      identificacao: true,
      dadosCliente: true,
      equipamento: true,
      defeitoRelatado: true,
      analiseTecnica: true,
      fotos: true,
      pecas: true,
      servicos: true,
      conclusao: true,
      termoGarantia: true,
      assinaturas: true,
    });
  };

  const deselectAllOptions = () => {
    setExportOptions({
      identificacao: false,
      dadosCliente: false,
      equipamento: false,
      defeitoRelatado: false,
      analiseTecnica: false,
      fotos: false,
      pecas: false,
      servicos: false,
      conclusao: false,
      termoGarantia: false,
      assinaturas: false,
    });
  };

  const openExportModal = (order: RepairOrder) => {
    setOrderToExport(order);
    setShowExportOptions(true);
  };

  // Carrega imagem e mantém proporções corretas com timeout
  const loadImageWithProportions = (url: string, maxWidth: number, maxHeight: number): Promise<{ data: string; width: number; height: number }> => {
    return new Promise((resolve) => {
      // Timeout de 5 segundos para cada imagem
      const timeout = setTimeout(() => {
        resolve({ data: '', width: 0, height: 0 });
      }, 5000);
      
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        clearTimeout(timeout);
        try {
          let { width, height } = img;
          
          // Calcular proporção mantendo aspect ratio
          const ratio = Math.min(maxWidth / width, maxHeight / height);
          width = width * ratio;
          height = height * ratio;
          
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          resolve({ data: canvas.toDataURL('image/jpeg', 0.92), width, height });
        } catch {
          resolve({ data: '', width: 0, height: 0 });
        }
      };
      img.onerror = () => {
        clearTimeout(timeout);
        resolve({ data: '', width: 0, height: 0 });
      };
      img.src = url;
    });
  };

  const generatePDF = async (order: RepairOrder | null) => {
    if (!order) {
      alert('Nenhuma ordem selecionada');
      return;
    }
    
    setGeneratingPdf(true);
    setShowExportOptions(false);
    
    // Usar setTimeout para permitir que a UI atualize
    await new Promise(resolve => setTimeout(resolve, 100));
    
    try {
      // Criar PDF
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 15;
      const contentWidth = pageWidth - (margin * 2);
      const footerHeight = 12;
      const maxY = pageHeight - footerHeight - 10;
      let y = 0;

      const addFooter = () => {
        const totalPages = pdf.getNumberOfPages();
        for (let i = 1; i <= totalPages; i++) {
          pdf.setPage(i);
          pdf.setFillColor(245, 245, 245);
          pdf.rect(0, pageHeight - footerHeight, pageWidth, footerHeight, 'F');
          pdf.setDrawColor(200, 200, 200);
          pdf.line(0, pageHeight - footerHeight, pageWidth, pageHeight - footerHeight);
          pdf.setFontSize(7);
          pdf.setTextColor(120, 120, 120);
          pdf.text(`Documento gerado pelo sistema Conab+ | ${new Date().toLocaleString('pt-BR')}`, margin, pageHeight - 4);
          pdf.text(`Página ${i} de ${totalPages}`, pageWidth - margin, pageHeight - 4, { align: 'right' });
        }
      };

      const checkNewPage = (neededHeight: number) => {
        if (y + neededHeight > maxY) {
          pdf.addPage();
          y = margin;
          return true;
        }
        return false;
      };

      // =====================================================
      // HEADER
      // =====================================================
      pdf.setFillColor(0, 51, 102);
      pdf.rect(0, 0, pageWidth, 32, 'F');
      pdf.setFillColor(0, 40, 80);
      pdf.rect(0, 0, pageWidth, 16, 'F');
      
      pdf.setFontSize(24);
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(255, 255, 255);
      pdf.text('CONAB+', margin, 14);
      
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'normal');
      pdf.setTextColor(180, 200, 220);
      pdf.text('Sistema de Gestão de Manutenção', margin, 22);
      
      y = 40;

      // =====================================================
      // TÍTULO DO DOCUMENTO
      // =====================================================
      pdf.setFillColor(240, 240, 240);
      pdf.roundedRect(margin, y, contentWidth, 12, 2, 2, 'F');
      pdf.setFontSize(13);
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(0, 51, 102);
      pdf.text('ANÁLISE TÉCNICA PARA ORÇAMENTO', pageWidth / 2, y + 8, { align: 'center' });
      y += 20;

      // =====================================================
      // IDENTIFICAÇÃO (OS e Data)
      // =====================================================
      if (exportOptions.identificacao) {
        pdf.setFillColor(240, 253, 244);
        pdf.setDrawColor(0, 166, 81);
        pdf.setLineWidth(0.8);
        pdf.roundedRect(margin, y, contentWidth, 20, 3, 3, 'FD');
        
        pdf.setFillColor(0, 166, 81);
        pdf.rect(margin, y, 4, 20, 'F');
        
        pdf.setFontSize(11);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Identificação', margin + 8, y + 7);
        
        pdf.setFontSize(9);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(60, 60, 60);
        
        const dateStr = new Date(order.createdAt).toLocaleDateString('pt-BR');
        pdf.setFont('helvetica', 'bold');
        pdf.text('O.S:', margin + 8, y + 15);
        pdf.text('Data:', margin + 60, y + 15);
        
        pdf.setFont('helvetica', 'normal');
        pdf.text(order.numeroOS, margin + 20, y + 15);
        pdf.text(dateStr, margin + 72, y + 15);
        
        y += 28;
      }

      // =====================================================
      // DADOS DO CLIENTE
      // =====================================================
      if (exportOptions.dadosCliente) {
        pdf.setFillColor(255, 255, 255);
        pdf.setDrawColor(220, 220, 220);
        pdf.setLineWidth(0.5);
        pdf.roundedRect(margin, y, contentWidth, 26, 2, 2, 'FD');
        
        pdf.setFillColor(0, 51, 102);
        pdf.rect(margin, y, 4, 26, 'F');
        
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Dados do Cliente', margin + 8, y + 7);
        
        pdf.setFontSize(9);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(80, 80, 80);
        pdf.text('Código:', margin + 8, y + 14);
        pdf.text('Cliente:', margin + 8, y + 21);
        pdf.text('Vendedor:', margin + 90, y + 21);
        
        pdf.setTextColor(0, 0, 0);
        pdf.text(order.codigoEntidade, margin + 25, y + 14);
        pdf.text(order.nomeCliente, margin + 25, y + 21);
        pdf.text(order.vendedorResponsavel, margin + 112, y + 21);
        
        y += 32;
      }

      // =====================================================
      // EQUIPAMENTO
      // =====================================================
      if (exportOptions.equipamento) {
        pdf.setFillColor(255, 255, 255);
        pdf.setDrawColor(220, 220, 220);
        pdf.roundedRect(margin, y, contentWidth, 32, 2, 2, 'FD');
        
        pdf.setFillColor(0, 166, 81);
        pdf.rect(margin, y, 4, 32, 'F');
        
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Equipamento', margin + 8, y + 7);
        
        pdf.setFontSize(9);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(80, 80, 80);
        
        // Linha 1: Fabricante e Modelo
        pdf.text('Fabricante:', margin + 8, y + 14);
        pdf.text('Modelo:', margin + 90, y + 14);
        
        pdf.setTextColor(0, 0, 0);
        pdf.setFont('helvetica', 'bold');
        pdf.text(order.fabricante, margin + 32, y + 14);
        pdf.text(order.modelo, margin + 108, y + 14);
        
        // Linha 2: Potência, Tensão, Tipo Fase
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(80, 80, 80);
        pdf.text('Potência:', margin + 8, y + 21);
        pdf.text('Tensão:', margin + 60, y + 21);
        pdf.text('Tipo:', margin + 110, y + 21);
        
        pdf.setTextColor(0, 0, 0);
        pdf.text(order.potencia || '-', margin + 28, y + 21);
        pdf.text(order.tensao || '-', margin + 78, y + 21);
        pdf.text(order.tipoFase === 'trifasico' ? 'Trifásico' : order.tipoFase === 'monofasico' ? 'Monofásico' : '-', margin + 123, y + 21);
        
        // Linha 3: Conexões
        pdf.setTextColor(80, 80, 80);
        pdf.text('Conexões:', margin + 8, y + 28);
        pdf.setTextColor(0, 0, 0);
        pdf.text(order.veioComConexoes ? 'Sim' : 'Não', margin + 30, y + 28);
        
        y += 40;
      }

      // =====================================================
      // DEFEITO RELATADO
      // =====================================================
      if (exportOptions.defeitoRelatado && order.defeitoRelatado) {
        checkNewPage(25);
        
        pdf.setFillColor(255, 255, 255);
        pdf.setDrawColor(220, 220, 220);
        const defeitoLines = pdf.splitTextToSize(order.defeitoRelatado, contentWidth - 16);
        const defeitoHeight = Math.max(defeitoLines.length * 4.5 + 14, 22);
        pdf.roundedRect(margin, y, contentWidth, defeitoHeight, 2, 2, 'FD');
        
        pdf.setFillColor(255, 180, 100);
        pdf.rect(margin, y, 4, defeitoHeight, 'F');
        
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Defeito Relatado pelo Cliente', margin + 8, y + 7);
        
        pdf.setFontSize(9);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(80, 60, 40);
        pdf.text(defeitoLines, margin + 8, y + 14);
        y += defeitoHeight + 6;
      }

      // =====================================================
      // ANÁLISE TÉCNICA EM BANCADA
      // =====================================================
      if (exportOptions.analiseTecnica && order.analiseTecnica && Array.isArray(order.analiseTecnica) && order.analiseTecnica.length > 0) {
        checkNewPage(40);
        
        // Calcular altura total da seção
        let totalAnaliseHeight = 30; // Texto introdutório
        for (const item of order.analiseTecnica) {
          const itemLines = pdf.splitTextToSize(item.descricao, contentWidth - 24);
          totalAnaliseHeight += itemLines.length * 4 + 16;
        }
        
        // Container principal com borda azul
        pdf.setFillColor(240, 248, 255);
        pdf.setDrawColor(0, 51, 102);
        pdf.setLineWidth(1);
        pdf.roundedRect(margin, y, contentWidth, totalAnaliseHeight + 15, 3, 3, 'FD');
        
        // Barra lateral azul
        pdf.setFillColor(0, 51, 102);
        pdf.rect(margin, y, 4, totalAnaliseHeight + 15, 'F');
        
        // Título
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Análise técnica em bancada', margin + 8, y + 7);
        y += 12;
        
        // Texto introdutório
        pdf.setFontSize(8);
        pdf.setFont('helvetica', 'italic');
        pdf.setTextColor(60, 80, 100);
        const introText = 'Após o processo de desmontagem e avaliação minuciosa de cada componente em ambiente controlado, foram identificadas as seguintes irregularidades:';
        const introLines = pdf.splitTextToSize(introText, contentWidth - 16);
        pdf.text(introLines, margin + 8, y);
        y += introLines.length * 4 + 6;
        
        // Itens de análise dentro do container
        for (const item of order.analiseTecnica) {
          const itemLines = pdf.splitTextToSize(item.descricao, contentWidth - 24);
          const itemHeight = itemLines.length * 4 + 10;
          
          // Background do item
          pdf.setFillColor(255, 255, 255);
          pdf.setDrawColor(180, 200, 220);
          pdf.setLineWidth(0.3);
          pdf.roundedRect(margin + 6, y, contentWidth - 12, itemHeight, 2, 2, 'FD');
          
          // Bolinha verde
          pdf.setFillColor(0, 166, 81);
          pdf.circle(margin + 10, y + 5, 1.5, 'F');
          
          // Título do item
          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(0, 51, 102);
          pdf.text(item.titulo, margin + 14, y + 6);
          
          // Descrição do item
          pdf.setFontSize(8);
          pdf.setFont('helvetica', 'normal');
          pdf.setTextColor(60, 60, 60);
          pdf.text(itemLines, margin + 14, y + 12);
          
          y += itemHeight + 3;
        }
        y += 10;
      }

      // =====================================================
      // REGISTRO FOTOGRÁFICO
      // =====================================================
      if (exportOptions.fotos) {
        const fotosEntrada = order.fotosEntrada || [];
        const fotosAnalise = order.fotosAnalise || [];
        const allPhotos = [
          ...fotosEntrada.map(f => ({ ...f, tipo: 'Entrada' })),
          ...fotosAnalise.map(f => ({ ...f, tipo: 'Análise' })),
          ...(order.fotoPlaquetaBomba ? [{ ...order.fotoPlaquetaBomba, tipo: 'Plaqueta Bomba' }] : []),
          ...(order.fotoPlaquetaMotor ? [{ ...order.fotoPlaquetaMotor, tipo: 'Plaqueta Motor' }] : [])
        ];

        if (allPhotos.length > 0) {
          checkNewPage(60);
          
          // Container
          pdf.setFillColor(255, 255, 255);
          pdf.setDrawColor(220, 220, 220);
          pdf.setLineWidth(0.5);
          
          pdf.setFontSize(10);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(0, 51, 102);
          pdf.text('Registro Fotográfico', margin, y);
          y += 8;

          const photoMaxWidth = 55;
          const photoMaxHeight = 45;
          const photosPerRow = 3;
          const photoSpacing = (contentWidth - (photosPerRow * photoMaxWidth)) / (photosPerRow - 1);
          
          let col = 0;
          let rowStartY = y;

          for (let i = 0; i < allPhotos.length; i++) {
            const photo = allPhotos[i];
            col = i % photosPerRow;
            
            if (col === 0 && i > 0) {
              rowStartY += photoMaxHeight + 20;
              if (checkNewPage(photoMaxHeight + 20)) {
                rowStartY = y;
              }
            }
            
            const xPos = margin + col * (photoMaxWidth + photoSpacing);
            const currentY = rowStartY;

            try {
              const imgResult = await loadImageWithProportions(photo.url, photoMaxWidth * 4, photoMaxHeight * 4);
              if (imgResult.data) {
                const imgWidth = Math.min(imgResult.width / 4, photoMaxWidth);
                const imgHeight = Math.min(imgResult.height / 4, photoMaxHeight);
                const imgX = xPos + (photoMaxWidth - imgWidth) / 2;
                const imgY = currentY + (photoMaxHeight - imgHeight) / 2;
                
                // Borda da foto
                pdf.setDrawColor(200, 200, 200);
                pdf.setLineWidth(0.3);
                pdf.roundedRect(xPos, currentY, photoMaxWidth, photoMaxHeight, 2, 2, 'S');
                
                pdf.addImage(imgResult.data, 'JPEG', imgX, imgY, imgWidth, imgHeight);
                
                // Legenda
                pdf.setFillColor(0, 51, 102);
                pdf.roundedRect(xPos, currentY + photoMaxHeight, photoMaxWidth, 12, 0, 0, 'F');
                pdf.setFontSize(7);
                pdf.setFont('helvetica', 'bold');
                pdf.setTextColor(255, 255, 255);
                const label = (photo.descricao || photo.tipo).substring(0, 25);
                pdf.text(label, xPos + photoMaxWidth / 2, currentY + photoMaxHeight + 7, { align: 'center' });
              }
            } catch {
              // Skip photo if loading fails
            }
          }
          
          const totalRows = Math.ceil(allPhotos.length / photosPerRow);
          y = rowStartY + totalRows * (photoMaxHeight + 20) + 5;
        }
      }

      // =====================================================
      // TABELA DE PEÇAS
      // =====================================================
      const pecasSelecionadas = order.pecasSelecionadas || [];
      if (exportOptions.pecas && pecasSelecionadas.length > 0) {
        checkNewPage(35);
        
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Peças a serem trocadas', margin, y);
        y += 6;

        pdf.setFillColor(0, 51, 102);
        pdf.roundedRect(margin, y, contentWidth, 8, 1, 1, 'F');
        
        pdf.setFontSize(8);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(255, 255, 255);
        pdf.text('Código', margin + 5, y + 5.5);
        pdf.text('Descrição', margin + 45, y + 5.5);
        pdf.text('Qtd', margin + contentWidth - 20, y + 5.5);
        y += 8;

        pecasSelecionadas.forEach((peca, idx) => {
          checkNewPage(8);
          
          pdf.setFillColor(idx % 2 === 0 ? 250 : 255, idx % 2 === 0 ? 250 : 255, idx % 2 === 0 ? 250 : 255);
          pdf.rect(margin, y, contentWidth, 7, 'F');
          pdf.setDrawColor(230, 230, 230);
          pdf.line(margin, y + 7, margin + contentWidth, y + 7);
          
          pdf.setFontSize(8);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(0, 51, 102);
          pdf.text(peca.codigo, margin + 5, y + 5);
          
          pdf.setFont('helvetica', 'normal');
          pdf.setTextColor(60, 60, 60);
          pdf.text(peca.descricao.substring(0, 50), margin + 45, y + 5);
          
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(0, 0, 0);
          pdf.text(String(peca.quantidade), margin + contentWidth - 17, y + 5);
          
          y += 7;
        });
        y += 8;
      }

      // =====================================================
      // TABELA DE SERVIÇOS
      // =====================================================
      const maoDeObra = order.maoDeObra || [];
      if (exportOptions.servicos && maoDeObra.length > 0) {
        checkNewPage(35);
        
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Serviços', margin, y);
        y += 6;

        pdf.setFillColor(0, 51, 102);
        pdf.roundedRect(margin, y, contentWidth, 8, 1, 1, 'F');
        
        pdf.setFontSize(8);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(255, 255, 255);
        pdf.text('Descrição', margin + 5, y + 5.5);
        pdf.text('Qtd', margin + contentWidth - 20, y + 5.5);
        y += 8;

        maoDeObra.forEach((mao, idx) => {
          checkNewPage(8);
          
          pdf.setFillColor(idx % 2 === 0 ? 250 : 255, idx % 2 === 0 ? 250 : 255, idx % 2 === 0 ? 250 : 255);
          pdf.rect(margin, y, contentWidth, 7, 'F');
          pdf.setDrawColor(230, 230, 230);
          pdf.line(margin, y + 7, margin + contentWidth, y + 7);
          
          pdf.setFontSize(8);
          pdf.setFont('helvetica', 'normal');
          pdf.setTextColor(60, 60, 60);
          pdf.text(mao.descricao.substring(0, 60), margin + 5, y + 5);
          
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(0, 0, 0);
          pdf.text(String(mao.quantidade), margin + contentWidth - 17, y + 5);
          
          y += 7;
        });
        y += 8;
      }

      // =====================================================
      // CONCLUSÃO E RECOMENDAÇÃO (após serviços)
      // =====================================================
      if (exportOptions.conclusao && order.conclusaoRecomendacao) {
        checkNewPage(25);
        
        pdf.setFillColor(255, 255, 255);
        pdf.setDrawColor(220, 220, 220);
        pdf.setLineWidth(0.5);
        const concLines = pdf.splitTextToSize(order.conclusaoRecomendacao, contentWidth - 16);
        const concHeight = Math.max(concLines.length * 4.5 + 14, 22);
        pdf.roundedRect(margin, y, contentWidth, concHeight, 2, 2, 'FD');
        
        pdf.setFillColor(0, 166, 81);
        pdf.rect(margin, y, 4, concHeight, 'F');
        
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Conclusão e recomendação', margin + 8, y + 7);
        
        pdf.setFontSize(9);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(30, 80, 50);
        pdf.text(concLines, margin + 8, y + 14);
        y += concHeight + 8;
      }

      // =====================================================
      // TERMOS DE GARANTIA
      // =====================================================
      if (exportOptions.termoGarantia) {
        checkNewPage(50);
        
        pdf.setFillColor(248, 250, 252);
        pdf.setDrawColor(200, 200, 200);
        
        const objetoLines = pdf.splitTextToSize(termoGarantia.objetoGarantia, contentWidth - 16);
        const exclusoesHeight = termoGarantia.exclusoes.length * 5 + 10;
        const termoHeight = objetoLines.length * 4 + exclusoesHeight + 35;
        
        checkNewPage(termoHeight);
        
        pdf.roundedRect(margin, y, contentWidth, termoHeight, 3, 3, 'FD');
        
        pdf.setFillColor(0, 51, 102);
        pdf.rect(margin, y, 4, termoHeight, 'F');
        
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('Termos de garantia', margin + 8, y + 8);
        y += 14;
        
        pdf.setFontSize(9);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('1. Objeto da garantia', margin + 8, y);
        y += 5;
        
        pdf.setFontSize(8);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(80, 80, 80);
        pdf.text(objetoLines, margin + 8, y);
        y += objetoLines.length * 4 + 6;
        
        pdf.setFontSize(9);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 51, 102);
        pdf.text('2. Exclusões', margin + 8, y);
        y += 5;
        
        pdf.setFontSize(8);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(80, 80, 80);
        pdf.text('A garantia será anulada em caso de:', margin + 8, y);
        y += 5;
        
        termoGarantia.exclusoes.forEach(exclusao => {
          pdf.text(`• ${exclusao}`, margin + 12, y);
          y += 4.5;
        });
        
        y += 10;
      }

      // =====================================================
      // ÁREA DE ASSINATURAS
      // =====================================================
      if (exportOptions.assinaturas) {
        checkNewPage(45);
        
        const sigY = Math.max(y + 10, pageHeight - footerHeight - 45);
        
        // Nome do usuário logado que está gerando o relatório
        const responsavelRelatorio = currentUser?.name || 'Responsável';
        
        pdf.setDrawColor(100, 100, 100);
        pdf.setLineWidth(0.4);
        
        // Assinatura do responsável pelo relatório (usuário logado)
        pdf.line(margin + 10, sigY + 15, margin + 75, sigY + 15);
        pdf.setFontSize(8);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(100, 100, 100);
        pdf.text('Responsável pelo Relatório', margin + 18, sigY + 20);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 0, 0);
        pdf.text(responsavelRelatorio, margin + 42.5, sigY + 26, { align: 'center' });
        
        // Assinatura do cliente
        pdf.setDrawColor(100, 100, 100);
        pdf.line(pageWidth - margin - 75, sigY + 15, pageWidth - margin - 10, sigY + 15);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor(100, 100, 100);
        pdf.text('Assinatura do Cliente', pageWidth - margin - 53, sigY + 20);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(0, 0, 0);
        pdf.text(order.nomeCliente, pageWidth - margin - 42.5, sigY + 26, { align: 'center' });
      }

      addFooter();
      pdf.save(`Analise-${order.numeroOS}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Erro ao gerar PDF: ' + (error instanceof Error ? error.message : 'Erro desconhecido'));
    } finally {
      setGeneratingPdf(false);
    }
  };

  const exportOptionLabels: Record<keyof ExportOptions, string> = {
    identificacao: 'Identificação (OS e Data)',
    dadosCliente: 'Dados do Cliente',
    equipamento: 'Equipamento',
    defeitoRelatado: 'Defeito Relatado',
    analiseTecnica: 'Análise Técnica em Bancada',
    fotos: 'Registro Fotográfico',
    pecas: 'Peças a Serem Trocadas',
    servicos: 'Serviços',
    conclusao: 'Conclusão e Recomendação',
    termoGarantia: 'Termos de Garantia',
    assinaturas: 'Área de Assinaturas',
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold text-[#003366]">Relatórios</h2>
        <p className="text-gray-500 mt-1 text-sm">Base de dados completa com histórico de ordens</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-5 h-5 text-[#00A651]" />
          <h3 className="font-semibold text-[#003366]">Filtros</h3>
          {Object.values(filters).some(v => v) && (
            <button 
              onClick={clearFilters}
              className="ml-auto text-sm text-red-500 hover:underline flex items-center gap-1"
            >
              <X className="w-4 h-4" /> Limpar
            </button>
          )}
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 md:gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Número TG</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={filters.tg}
                onChange={(e) => setFilters(prev => ({ ...prev, tg: e.target.value }))}
                className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
                placeholder="TG-001"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Código Entidade</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={filters.codigoEntidade}
                onChange={(e) => setFilters(prev => ({ ...prev, codigoEntidade: e.target.value }))}
                className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
                placeholder="CLI-001"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Número OS</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={filters.os}
                onChange={(e) => setFilters(prev => ({ ...prev, os: e.target.value }))}
                className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
                placeholder="OS-2024-001"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Fabricante</label>
            <select
              value={filters.fabricante}
              onChange={(e) => setFilters(prev => ({ ...prev, fabricante: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#00A651] focus:border-transparent bg-white"
            >
              <option value="">Todos</option>
              {fabricantes.map((fab: string) => (
                <option key={fab} value={fab}>{fab}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Modelo</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={filters.modelo}
                onChange={(e) => setFilters(prev => ({ ...prev, modelo: e.target.value }))}
                className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
                placeholder="Modelo"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-4 md:px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <span className="text-sm text-gray-500">
            {filteredOrders.length} registro(s) encontrado(s)
          </span>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px]">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">TG / OS</th>
                <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Cliente</th>
                <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Equipamento</th>
                <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Data</th>
                <th className="text-center px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-400">
                    <FileText className="w-10 h-10 mx-auto mb-2 opacity-50" />
                    <p>Nenhum registro encontrado</p>
                  </td>
                </tr>
              ) : (
                filteredOrders.map(order => (
                  <tr key={order.id} className="hover:bg-gray-50 transition">
                    <td className="px-4 md:px-6 py-4">
                      <div className="text-sm font-medium text-[#003366]">TG: {order.numeroTG}</div>
                      <div className="text-xs text-gray-500">OS: {order.numeroOS}</div>
                    </td>
                    <td className="px-4 md:px-6 py-4">
                      <div className="text-sm font-medium">{order.nomeCliente}</div>
                      <div className="text-xs text-gray-500">{order.codigoEntidade}</div>
                    </td>
                    <td className="px-4 md:px-6 py-4">
                      <div className="text-sm">{order.fabricante}</div>
                      <div className="text-xs text-gray-500">{order.modelo}</div>
                    </td>
                    <td className="px-4 md:px-6 py-4">
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                        {getStatusLabel(order.status)}
                      </span>
                    </td>
                    <td className="px-4 md:px-6 py-4 text-sm text-gray-500">
                      {new Date(order.createdAt).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="px-4 md:px-6 py-4">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="p-2 text-gray-400 hover:text-[#003366] hover:bg-gray-100 rounded-lg transition"
                          title="Visualizar"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {canExportPDF && (
                          <button
                            onClick={() => openExportModal(order)}
                            disabled={generatingPdf}
                            className="p-2 text-gray-400 hover:text-[#00A651] hover:bg-green-50 rounded-lg transition disabled:opacity-50"
                            title="Exportar PDF"
                          >
                            {generatingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Export Options Modal */}
      {showExportOptions && orderToExport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" onClick={() => setShowExportOptions(false)}>
          <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between z-10">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#00A651]" />
                <h3 className="font-semibold text-[#003366]">Opções de Exportação</h3>
              </div>
              <button
                onClick={() => setShowExportOptions(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4 space-y-4">
              <p className="text-sm text-gray-500">
                Selecione os itens que deseja incluir no PDF:
              </p>
              
              <div className="flex gap-2">
                <button
                  onClick={selectAllOptions}
                  className="text-xs px-3 py-1.5 bg-[#003366] text-white rounded-lg hover:bg-[#002244] transition"
                >
                  Selecionar Todos
                </button>
                <button
                  onClick={deselectAllOptions}
                  className="text-xs px-3 py-1.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition"
                >
                  Desmarcar Todos
                </button>
              </div>
              
              <div className="space-y-2">
                {(Object.keys(exportOptions) as Array<keyof ExportOptions>).map(key => (
                  <label
                    key={key}
                    className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 cursor-pointer transition"
                  >
                    <input
                      type="checkbox"
                      checked={exportOptions[key]}
                      onChange={() => toggleExportOption(key)}
                      className="w-4 h-4 rounded border-gray-300 text-[#00A651] focus:ring-[#00A651]"
                    />
                    <span className="text-sm text-gray-700">{exportOptionLabels[key]}</span>
                  </label>
                ))}
              </div>
              
              <div className="pt-4 border-t flex gap-2">
                <button
                  onClick={() => setShowExportOptions(false)}
                  className="flex-1 px-4 py-2.5 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    if (orderToExport) {
                      generatePDF(orderToExport);
                    }
                  }}
                  disabled={generatingPdf || !Object.values(exportOptions).some(v => v) || !orderToExport}
                  className="flex-1 px-4 py-2.5 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {generatingPdf ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      Gerar PDF
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" onClick={() => setSelectedOrder(null)}>
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between z-10">
              <h3 className="font-semibold text-[#003366]">Detalhes da Ordem</h3>
              <div className="flex items-center gap-2">
                {canExportPDF && (
                  <button
                    onClick={() => openExportModal(selectedOrder)}
                    disabled={generatingPdf}
                    className="flex items-center gap-2 px-3 md:px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition disabled:opacity-50 text-sm"
                  >
                    {generatingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                    <span className="hidden sm:inline">Exportar PDF</span>
                  </button>
                )}
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="p-4 md:p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-sm text-gray-500">TG:</span>
                  <p className="font-medium">{selectedOrder.numeroTG}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">OS:</span>
                  <p className="font-medium">{selectedOrder.numeroOS}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Cliente:</span>
                  <p className="font-medium">{selectedOrder.nomeCliente}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Código:</span>
                  <p className="font-medium">{selectedOrder.codigoEntidade}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Equipamento:</span>
                  <p className="font-medium">{selectedOrder.fabricante} - {selectedOrder.modelo}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Vendedor:</span>
                  <p className="font-medium">{selectedOrder.vendedorResponsavel}</p>
                </div>
                {selectedOrder.potencia && (
                  <div>
                    <span className="text-sm text-gray-500">Potência:</span>
                    <p className="font-medium">{selectedOrder.potencia}</p>
                  </div>
                )}
                {selectedOrder.tensao && (
                  <div>
                    <span className="text-sm text-gray-500">Tensão:</span>
                    <p className="font-medium">{selectedOrder.tensao}</p>
                  </div>
                )}
                {selectedOrder.mecanicoResponsavel && (
                  <div className="col-span-2">
                    <span className="text-sm text-gray-500">Mecânico:</span>
                    <p className="font-medium">{selectedOrder.mecanicoResponsavel}</p>
                  </div>
                )}
              </div>
              
              {selectedOrder.analiseTecnica && selectedOrder.analiseTecnica.length > 0 && (
                <div>
                  <span className="text-sm text-gray-500">Análise Técnica:</span>
                  <div className="mt-2 space-y-2">
                    {selectedOrder.analiseTecnica.map((item, idx) => (
                      <div key={idx} className="p-3 bg-gray-50 rounded-lg">
                        <p className="font-medium text-[#003366]">{item.titulo}</p>
                        <p className="text-sm text-gray-600">{item.descricao}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedOrder.pecasSelecionadas && selectedOrder.pecasSelecionadas.length > 0 && (
                <div>
                  <span className="text-sm text-gray-500">Peças ({selectedOrder.pecasSelecionadas.length}):</span>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {selectedOrder.pecasSelecionadas.map(p => (
                      <span key={p.id} className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs">
                        {p.codigo} - {p.descricao} (x{p.quantidade})
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selectedOrder.maoDeObra && selectedOrder.maoDeObra.length > 0 && (
                <div>
                  <span className="text-sm text-gray-500">Serviços:</span>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {selectedOrder.maoDeObra.map(m => (
                      <span key={m.id} className="px-2 py-1 bg-green-50 text-green-700 rounded text-xs">
                        {m.descricao} (x{m.quantidade})
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {(selectedOrder.fotosEntrada.length > 0 || selectedOrder.fotosAnalise.length > 0) && (
                <div>
                  <span className="text-sm text-gray-500">Fotos:</span>
                  <div className="mt-2 grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {[...selectedOrder.fotosEntrada, ...selectedOrder.fotosAnalise].slice(0, 8).map((foto, idx) => (
                      <div key={idx} className="relative">
                        <img src={foto.url} alt={foto.descricao || `Foto ${idx + 1}`} className="w-full h-20 object-cover rounded border" />
                        {foto.descricao && (
                          <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-0.5 truncate rounded-b">
                            {foto.descricao}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
