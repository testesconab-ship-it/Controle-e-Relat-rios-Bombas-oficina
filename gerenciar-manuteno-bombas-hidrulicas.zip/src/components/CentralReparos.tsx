import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RepairOrder, RepairStatus } from '../types';
import { 
  Plus, 
  Search, 
  Clock, 
  CheckCircle,
  Clipboard,
  ArrowRight
} from 'lucide-react';
import { RepairForm } from './RepairForm';
import { RepairDetail } from './RepairDetail';

export function CentralReparos() {
  const { repairOrders, statusConfig } = useApp();
  const [selectedOrder, setSelectedOrder] = useState<RepairOrder | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingOrder, setEditingOrder] = useState<RepairOrder | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');

  const filteredOrders = repairOrders.filter(order => 
    order.nomeCliente.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.numeroOS.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.numeroTG.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.fabricante.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusIcon = (status: RepairStatus) => {
    switch (status) {
      case 'entrada': return Clipboard;
      case 'analise': return Clock;
      case 'concluido': return CheckCircle;
      default: return Clipboard;
    }
  };

  const getStatusColor = (status: RepairStatus) => {
    switch (status) {
      case 'entrada': return 'border-blue-400 bg-blue-50';
      case 'analise': return 'border-yellow-400 bg-yellow-50';
      case 'concluido': return 'border-green-400 bg-green-50';
      default: return 'border-gray-400 bg-gray-50';
    }
  };

  const getStatusBadgeColor = (status: RepairStatus) => {
    switch (status) {
      case 'entrada': return 'bg-blue-100 text-blue-700';
      case 'analise': return 'bg-yellow-100 text-yellow-700';
      case 'concluido': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const ordersByStatus: Record<RepairStatus, RepairOrder[]> = {
    entrada: filteredOrders.filter(o => o.status === 'entrada'),
    analise: filteredOrders.filter(o => o.status === 'analise'),
    concluido: filteredOrders.filter(o => o.status === 'concluido'),
  };

  const handleNewOrder = () => {
    setEditingOrder(null);
    setShowForm(true);
  };

  const handleEditOrder = (order: RepairOrder) => {
    setEditingOrder(order);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingOrder(null);
  };

  if (showForm) {
    return (
      <RepairForm 
        order={editingOrder} 
        onClose={handleCloseForm} 
      />
    );
  }

  if (selectedOrder) {
    return (
      <RepairDetail 
        order={selectedOrder} 
        onClose={() => setSelectedOrder(null)}
        onEdit={handleEditOrder}
      />
    );
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-[#003366]">Central de Reparos</h2>
          <p className="text-gray-500 mt-1 text-sm">Gerencie as ordens de serviço</p>
        </div>
        <button
          onClick={handleNewOrder}
          className="flex items-center justify-center gap-2 px-4 md:px-6 py-2.5 md:py-3 bg-[#00A651] text-white font-semibold rounded-lg hover:bg-[#008C44] transition shadow-lg"
        >
          <Plus className="w-5 h-5" />
          <span>Nova Entrada</span>
        </button>
      </div>

      {/* Search and View Toggle */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por cliente, OS, TG ou fabricante..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 md:py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent text-base"
          />
        </div>
        <div className="flex bg-gray-100 rounded-lg p-1 self-start">
          <button
            onClick={() => setViewMode('kanban')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition ${
              viewMode === 'kanban' 
                ? 'bg-white shadow text-[#003366]' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Kanban
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition ${
              viewMode === 'list' 
                ? 'bg-white shadow text-[#003366]' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Lista
          </button>
        </div>
      </div>

      {/* Kanban View */}
      {viewMode === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
          {statusConfig.map(status => {
            const Icon = getStatusIcon(status.id);
            const orders = ordersByStatus[status.id] || [];
            
            return (
              <div key={status.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div className={`px-4 py-3 border-b-2 ${getStatusColor(status.id)} flex items-center justify-between`}>
                  <div className="flex items-center gap-2">
                    <Icon className="w-5 h-5 text-gray-600" />
                    <span className="font-semibold text-gray-700 text-sm md:text-base">{status.label}</span>
                  </div>
                  <span className="px-2 py-0.5 bg-white/80 rounded-full text-sm font-medium">
                    {orders.length}
                  </span>
                </div>
                <div className="p-3 md:p-4 space-y-3 max-h-[60vh] md:max-h-[65vh] overflow-y-auto">
                  {orders.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      <Clipboard className="w-10 h-10 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Nenhuma ordem</p>
                    </div>
                  ) : (
                    orders.map((order: RepairOrder) => (
                      <button
                        key={order.id}
                        onClick={() => setSelectedOrder(order)}
                        className="w-full text-left p-3 md:p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition border border-gray-100"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <span className="font-semibold text-[#003366] text-sm">TG: {order.numeroTG}</span>
                          <ArrowRight className="w-4 h-4 text-gray-400" />
                        </div>
                        <p className="text-sm text-gray-600 mb-1 truncate">{order.nomeCliente}</p>
                        <p className="text-xs text-gray-400 mb-2">OS: {order.numeroOS}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-gray-500">{order.fabricante}</span>
                          <span className="text-xs text-gray-400">
                            {new Date(order.createdAt).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* List View */}
      {viewMode === 'list' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px]">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">TG / OS</th>
                  <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Cliente</th>
                  <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Equipamento</th>
                  <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="text-left px-4 md:px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Data</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-gray-400">
                      <Clipboard className="w-10 h-10 mx-auto mb-2 opacity-50" />
                      <p>Nenhuma ordem encontrada</p>
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map(order => (
                    <tr
                      key={order.id}
                      onClick={() => setSelectedOrder(order)}
                      className="hover:bg-gray-50 cursor-pointer transition"
                    >
                      <td className="px-4 md:px-6 py-4">
                        <div className="text-sm font-medium text-[#003366]">TG: {order.numeroTG}</div>
                        <div className="text-xs text-gray-500">OS: {order.numeroOS}</div>
                      </td>
                      <td className="px-4 md:px-6 py-4">
                        <div className="text-sm font-medium">{order.nomeCliente}</div>
                        <div className="text-xs text-gray-500">{order.codigoEntidade}</div>
                      </td>
                      <td className="px-4 md:px-6 py-4">
                        <div className="text-sm">{order.fabricante}</div>
                        <div className="text-xs text-gray-500">{order.modelo}</div>
                      </td>
                      <td className="px-4 md:px-6 py-4">
                        <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(order.status)}`}>
                          {statusConfig.find(s => s.id === order.status)?.label || order.status}
                        </span>
                      </td>
                      <td className="px-4 md:px-6 py-4 text-sm text-gray-500">
                        {new Date(order.createdAt).toLocaleDateString('pt-BR')}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
