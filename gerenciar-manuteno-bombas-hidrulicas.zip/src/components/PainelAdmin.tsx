import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { FieldPermission, TabPermission, UserPermissions, DEFAULT_ADMIN_PERMISSIONS, DEFAULT_USER_PERMISSIONS } from '../types';
import { 
  Users, 
  Plus,
  Trash2,
  Edit,
  Save,
  X,
  Shield,
  FileText,
  Package,
  MessageSquare,
  Wrench,
  Layers,
  Settings
} from 'lucide-react';

const ALL_TABS: { id: TabPermission; label: string }[] = [
  { id: 'reparos', label: 'Central de Reparos' },
  { id: 'relatorios', label: 'Relatórios' },
  { id: 'admin', label: 'Painel Admin' },
  { id: 'perfil', label: 'Perfil' },
];

const ALL_FIELDS: { id: FieldPermission; label: string; stage: string }[] = [
  // Entrada
  { id: 'codigoEntidade', label: 'Código Entidade', stage: 'Entrada' },
  { id: 'nomeCliente', label: 'Nome Cliente', stage: 'Entrada' },
  { id: 'numeroOS', label: 'Número OS', stage: 'Entrada' },
  { id: 'numeroTG', label: 'Número TG', stage: 'Entrada' },
  { id: 'vendedorResponsavel', label: 'Vendedor', stage: 'Entrada' },
  { id: 'classeReceitaDespesa', label: 'Classe Receita/Despesa', stage: 'Entrada' },
  { id: 'fabricante', label: 'Fabricante', stage: 'Entrada' },
  { id: 'modelo', label: 'Modelo', stage: 'Entrada' },
  { id: 'potencia', label: 'Potência', stage: 'Entrada' },
  { id: 'tensao', label: 'Tensão', stage: 'Entrada' },
  { id: 'tipoFase', label: 'Tipo Fase', stage: 'Entrada' },
  { id: 'defeitoRelatado', label: 'Defeito Relatado', stage: 'Entrada' },
  { id: 'veioComConexoes', label: 'Veio com Conexões', stage: 'Entrada' },
  { id: 'fotosEntrada', label: 'Fotos Entrada', stage: 'Entrada' },
  // Análise
  { id: 'mecanicoResponsavel', label: 'Mecânico', stage: 'Análise' },
  { id: 'analiseTecnica', label: 'Análise Técnica', stage: 'Análise' },
  { id: 'conclusaoRecomendacao', label: 'Conclusão e Recomendação', stage: 'Análise' },
  { id: 'fotosAnalise', label: 'Fotos Análise', stage: 'Análise' },
  { id: 'fotoPlaquetaBomba', label: 'Foto Plaqueta Bomba', stage: 'Análise' },
  { id: 'fotoPlaquetaMotor', label: 'Foto Plaqueta Motor', stage: 'Análise' },
  { id: 'pecasSelecionadas', label: 'Peças', stage: 'Análise' },
  { id: 'maoDeObra', label: 'Mão de Obra', stage: 'Análise' },
  { id: 'previsaoEntrega', label: 'Previsão Entrega', stage: 'Análise' },
];

export function PainelAdmin() {
  const { 
    users, 
    addUser, 
    updateUser, 
    deleteUser, 
    fabricantes, 
    addFabricante, 
    updateFabricante, 
    deleteFabricante,
    frasesDefeito,
    addFraseDefeito,
    updateFraseDefeito,
    deleteFraseDefeito,
    tiposServico,
    addTipoServico,
    updateTipoServico,
    deleteTipoServico,
    termoGarantia,
    updateTermoGarantia,
    statusConfig,
    updateStatusConfig,
    fieldConfig,
    updateFieldConfig
  } = useApp();
  
  const [activeTab, setActiveTab] = useState<'users' | 'etapas' | 'campos' | 'fabricantes' | 'frases' | 'servicos' | 'permissions' | 'termo'>('users');
  const [showAddUser, setShowAddUser] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editingPermissionsUserId, setEditingPermissionsUserId] = useState<string | null>(null);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: 'user' as 'admin' | 'user' });
  
  // Fabricantes
  const [newFabricante, setNewFabricante] = useState('');
  const [editingFabricante, setEditingFabricante] = useState<{ old: string; new: string } | null>(null);
  
  // Frases Defeito
  const [newFrase, setNewFrase] = useState('');
  const [editingFraseId, setEditingFraseId] = useState<string | null>(null);
  const [editingFraseText, setEditingFraseText] = useState('');
  
  // Tipos de Serviço
  const [newServico, setNewServico] = useState({ titulo: '', descricao: '' });
  const [editingServicoId, setEditingServicoId] = useState<string | null>(null);
  const [editingServicoData, setEditingServicoData] = useState({ titulo: '', descricao: '' });
  
  // Termo
  const [termoEdit, setTermoEdit] = useState(termoGarantia);
  const [newExclusao, setNewExclusao] = useState('');
  
  // Etapas
  const [editingStatusId, setEditingStatusId] = useState<string | null>(null);
  const [editingStatusLabel, setEditingStatusLabel] = useState('');
  
  // Campos
  const [localFieldConfig, setLocalFieldConfig] = useState(fieldConfig);

  // User being edited
  const [editUserData, setEditUserData] = useState({ name: '', email: '', password: '' });
  
  // Permissions being edited
  const [editPermissions, setEditPermissions] = useState<UserPermissions | null>(null);

  const handleAddUser = () => {
    if (!newUser.name || !newUser.email || !newUser.password) return;
    addUser(newUser);
    setNewUser({ name: '', email: '', password: '', role: 'user' });
    setShowAddUser(false);
  };

  const handleStartEditUser = (user: typeof users[0]) => {
    setEditingUserId(user.id);
    setEditUserData({ name: user.name, email: user.email, password: user.password });
  };

  const handleSaveUser = (userId: string) => {
    updateUser(userId, editUserData);
    setEditingUserId(null);
  };

  const handleStartEditPermissions = (user: typeof users[0]) => {
    setEditingPermissionsUserId(user.id);
    setEditPermissions(user.permissions || DEFAULT_USER_PERMISSIONS);
  };

  const handleSavePermissions = (userId: string) => {
    if (editPermissions) {
      updateUser(userId, { permissions: editPermissions });
    }
    setEditingPermissionsUserId(null);
    setEditPermissions(null);
  };

  const toggleTab = (tab: TabPermission) => {
    if (!editPermissions) return;
    const newTabs = editPermissions.tabs.includes(tab)
      ? editPermissions.tabs.filter(t => t !== tab)
      : [...editPermissions.tabs, tab];
    setEditPermissions({ ...editPermissions, tabs: newTabs });
  };

  const toggleField = (field: FieldPermission) => {
    if (!editPermissions) return;
    const newFields = editPermissions.fields.includes(field)
      ? editPermissions.fields.filter(f => f !== field)
      : [...editPermissions.fields, field];
    setEditPermissions({ ...editPermissions, fields: newFields });
  };

  const handleAddFabricante = () => {
    if (!newFabricante.trim()) return;
    addFabricante(newFabricante.trim());
    setNewFabricante('');
  };

  const handleSaveFabricante = () => {
    if (editingFabricante) {
      updateFabricante(editingFabricante.old, editingFabricante.new);
      setEditingFabricante(null);
    }
  };

  const handleAddFrase = () => {
    if (!newFrase.trim()) return;
    addFraseDefeito(newFrase.trim());
    setNewFrase('');
  };

  const handleSaveFrase = () => {
    if (editingFraseId && editingFraseText.trim()) {
      updateFraseDefeito(editingFraseId, editingFraseText.trim());
      setEditingFraseId(null);
      setEditingFraseText('');
    }
  };

  const handleAddServico = () => {
    if (!newServico.titulo.trim() || !newServico.descricao.trim()) return;
    addTipoServico(newServico.titulo.trim(), newServico.descricao.trim());
    setNewServico({ titulo: '', descricao: '' });
  };

  const handleSaveServico = () => {
    if (editingServicoId && editingServicoData.titulo.trim() && editingServicoData.descricao.trim()) {
      updateTipoServico(editingServicoId, editingServicoData.titulo.trim(), editingServicoData.descricao.trim());
      setEditingServicoId(null);
      setEditingServicoData({ titulo: '', descricao: '' });
    }
  };

  const handleSaveTermo = () => {
    updateTermoGarantia(termoEdit);
  };

  const handleAddExclusao = () => {
    if (!newExclusao.trim()) return;
    setTermoEdit(prev => ({
      ...prev,
      exclusoes: [...prev.exclusoes, newExclusao.trim()]
    }));
    setNewExclusao('');
  };

  const handleRemoveExclusao = (index: number) => {
    setTermoEdit(prev => ({
      ...prev,
      exclusoes: prev.exclusoes.filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold text-[#003366]">Painel Administrativo</h2>
        <p className="text-gray-500 mt-1 text-sm">Gerencie usuários, configurações e dados do sistema</p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b pb-2 overflow-x-auto">
        {[
          { id: 'users', label: 'Usuários', icon: Users },
          { id: 'etapas', label: 'Etapas', icon: Layers },
          { id: 'campos', label: 'Campos', icon: Settings },
          { id: 'permissions', label: 'Permissões', icon: Shield },
          { id: 'fabricantes', label: 'Fabricantes', icon: Package },
          { id: 'frases', label: 'Frases Defeito', icon: MessageSquare },
          { id: 'servicos', label: 'Tipos de Serviço', icon: Wrench },
          { id: 'termo', label: 'Termo', icon: FileText },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`flex items-center gap-2 px-3 md:px-4 py-2 rounded-lg font-medium transition whitespace-nowrap text-sm ${
              activeTab === tab.id
                ? 'bg-[#003366] text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-[#003366]">Gestão de Usuários</h3>
            <button
              onClick={() => setShowAddUser(true)}
              className="flex items-center gap-2 px-3 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition text-sm"
            >
              <Plus className="w-4 h-4" />
              Novo Usuário
            </button>
          </div>

          {/* Add User Form */}
          {showAddUser && (
            <div className="mb-4 p-4 bg-gray-50 rounded-lg border">
              <h4 className="font-medium mb-3">Novo Usuário</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                <input
                  type="text"
                  placeholder="Nome"
                  value={newUser.name}
                  onChange={(e) => setNewUser(prev => ({ ...prev, name: e.target.value }))}
                  className="px-3 py-2 border rounded-lg"
                />
                <input
                  type="email"
                  placeholder="E-mail"
                  value={newUser.email}
                  onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                  className="px-3 py-2 border rounded-lg"
                />
                <input
                  type="password"
                  placeholder="Senha"
                  value={newUser.password}
                  onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                  className="px-3 py-2 border rounded-lg"
                />
                <select
                  value={newUser.role}
                  onChange={(e) => setNewUser(prev => ({ ...prev, role: e.target.value as 'admin' | 'user' }))}
                  className="px-3 py-2 border rounded-lg bg-white"
                >
                  <option value="user">Usuário</option>
                  <option value="admin">Administrador</option>
                </select>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleAddUser}
                  className="px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition text-sm"
                >
                  Criar Usuário
                </button>
                <button
                  onClick={() => setShowAddUser(false)}
                  className="px-4 py-2 border rounded-lg hover:bg-gray-100 transition text-sm"
                >
                  Cancelar
                </button>
              </div>
            </div>
          )}

          {/* Users List */}
          <div className="space-y-3">
            {users.map(user => (
              <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                {editingUserId === user.id ? (
                  <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-2 mr-2">
                    <input
                      type="text"
                      value={editUserData.name}
                      onChange={(e) => setEditUserData(prev => ({ ...prev, name: e.target.value }))}
                      className="px-2 py-1 border rounded text-sm"
                      placeholder="Nome"
                    />
                    <input
                      type="email"
                      value={editUserData.email}
                      onChange={(e) => setEditUserData(prev => ({ ...prev, email: e.target.value }))}
                      className="px-2 py-1 border rounded text-sm"
                      placeholder="E-mail"
                    />
                    <input
                      type="password"
                      value={editUserData.password}
                      onChange={(e) => setEditUserData(prev => ({ ...prev, password: e.target.value }))}
                      className="px-2 py-1 border rounded text-sm"
                      placeholder="Senha"
                    />
                  </div>
                ) : (
                  <div className="flex-1">
                    <p className="font-medium">{user.name}</p>
                    <p className="text-sm text-gray-500">{user.email}</p>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-xs ${
                    user.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {user.role === 'admin' ? 'Admin' : 'Usuário'}
                  </span>
                  {editingUserId === user.id ? (
                    <>
                      <button
                        onClick={() => handleSaveUser(user.id)}
                        className="p-1 text-green-600 hover:bg-green-100 rounded"
                      >
                        <Save className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingUserId(null)}
                        className="p-1 text-gray-600 hover:bg-gray-200 rounded"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => handleStartEditUser(user)}
                        className="p-1 text-blue-600 hover:bg-blue-100 rounded"
                        title="Editar dados"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteUser(user.id)}
                        className="p-1 text-red-600 hover:bg-red-100 rounded"
                        title="Excluir"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Etapas Tab */}
      {activeTab === 'etapas' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <h3 className="font-semibold text-[#003366] mb-4">Configuração de Etapas</h3>
          <p className="text-sm text-gray-500 mb-4">Edite os nomes das etapas do fluxo de trabalho.</p>
          
          <div className="space-y-3">
            {statusConfig.map((status) => (
              <div key={status.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                {editingStatusId === status.id ? (
                  <div className="flex-1 flex items-center gap-2">
                    <input
                      type="text"
                      value={editingStatusLabel}
                      onChange={(e) => setEditingStatusLabel(e.target.value)}
                      className="flex-1 px-3 py-2 border rounded-lg"
                    />
                  </div>
                ) : (
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: status.color }}
                      />
                      <span className="font-medium">{status.label}</span>
                    </div>
                    <span className="text-sm text-gray-500">ID: {status.id}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  {editingStatusId === status.id ? (
                    <>
                      <button
                        onClick={() => {
                          const newConfig = statusConfig.map(s => 
                            s.id === status.id ? { ...s, label: editingStatusLabel } : s
                          );
                          updateStatusConfig(newConfig);
                          setEditingStatusId(null);
                        }}
                        className="p-1 text-green-600 hover:bg-green-100 rounded"
                      >
                        <Save className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingStatusId(null)}
                        className="p-1 text-gray-600 hover:bg-gray-200 rounded"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => {
                        setEditingStatusId(status.id);
                        setEditingStatusLabel(status.label);
                      }}
                      className="p-1 text-blue-600 hover:bg-blue-100 rounded"
                      title="Editar"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Campos Tab */}
      {activeTab === 'campos' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <h3 className="font-semibold text-[#003366] mb-4">Configuração de Campos Obrigatórios</h3>
          <p className="text-sm text-gray-500 mb-4">Defina quais campos são obrigatórios para salvar o formulário.</p>
          
          {['entrada', 'analise'].map((stage) => (
            <div key={stage} className="mb-6">
              <h4 className="font-medium text-[#003366] mb-3 capitalize">
                {stage === 'entrada' ? '📥 Etapa 1: Entrada' : '🔧 Etapa 2: Análise'}
              </h4>
              <div className="space-y-2">
                {localFieldConfig
                  .filter(field => field.stage === stage)
                  .map((field) => (
                    <div 
                      key={field.name} 
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <span className="font-medium">{field.label}</span>
                      <button
                        onClick={() => {
                          const newConfig = localFieldConfig.map(f => 
                            f.name === field.name ? { ...f, required: !f.required } : f
                          );
                          setLocalFieldConfig(newConfig);
                        }}
                        className={`px-3 py-1 rounded-lg text-sm font-medium transition ${
                          field.required
                            ? 'bg-red-100 text-red-700'
                            : 'bg-gray-200 text-gray-600'
                        }`}
                      >
                        {field.required ? 'Obrigatório' : 'Opcional'}
                      </button>
                    </div>
                  ))}
              </div>
            </div>
          ))}
          
          <button
            onClick={() => updateFieldConfig(localFieldConfig)}
            className="px-6 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Salvar Configurações
          </button>
        </div>
      )}

      {/* Permissions Tab */}
      {activeTab === 'permissions' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <h3 className="font-semibold text-[#003366] mb-4">Permissões de Usuários</h3>
          
          <div className="space-y-3">
            {users.map(user => (
              <div key={user.id} className="border rounded-lg overflow-hidden">
                <div className="flex items-center justify-between p-3 bg-gray-50">
                  <div>
                    <p className="font-medium">{user.name}</p>
                    <p className="text-sm text-gray-500">{user.email}</p>
                  </div>
                  <button
                    onClick={() => editingPermissionsUserId === user.id 
                      ? handleSavePermissions(user.id) 
                      : handleStartEditPermissions(user)
                    }
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition ${
                      editingPermissionsUserId === user.id
                        ? 'bg-green-600 text-white hover:bg-green-700'
                        : 'bg-[#003366] text-white hover:bg-[#002244]'
                    }`}
                  >
                    {editingPermissionsUserId === user.id ? (
                      <>
                        <Save className="w-4 h-4" />
                        Salvar
                      </>
                    ) : (
                      <>
                        <Shield className="w-4 h-4" />
                        Editar
                      </>
                    )}
                  </button>
                </div>
                
                {editingPermissionsUserId === user.id && editPermissions && (
                  <div className="p-4 space-y-4">
                    {/* Tabs */}
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-2">Acesso às Abas</p>
                      <div className="flex flex-wrap gap-2">
                        {ALL_TABS.map(tab => (
                          <button
                            key={tab.id}
                            onClick={() => toggleTab(tab.id)}
                            className={`px-3 py-1.5 rounded-lg text-sm transition ${
                              editPermissions.tabs.includes(tab.id)
                                ? 'bg-[#00A651] text-white'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                          >
                            {tab.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    {/* Special permissions */}
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-2">Permissões Especiais</p>
                      <div className="flex flex-wrap gap-2">
                        <button
                          onClick={() => setEditPermissions({
                            ...editPermissions,
                            canEditOrders: !editPermissions.canEditOrders
                          })}
                          className={`px-3 py-1.5 rounded-lg text-sm transition ${
                            editPermissions.canEditOrders
                              ? 'bg-[#00A651] text-white'
                              : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          Editar Ordens
                        </button>
                        <button
                          onClick={() => setEditPermissions({
                            ...editPermissions,
                            canDeleteOrders: !editPermissions.canDeleteOrders
                          })}
                          className={`px-3 py-1.5 rounded-lg text-sm transition ${
                            editPermissions.canDeleteOrders
                              ? 'bg-[#00A651] text-white'
                              : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          Excluir Ordens
                        </button>
                        <button
                          onClick={() => setEditPermissions({
                            ...editPermissions,
                            canExportPDF: !editPermissions.canExportPDF
                          })}
                          className={`px-3 py-1.5 rounded-lg text-sm transition ${
                            editPermissions.canExportPDF
                              ? 'bg-[#00A651] text-white'
                              : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          Exportar PDF
                        </button>
                      </div>
                    </div>
                    
                    {/* Fields */}
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-2">Campos Editáveis</p>
                      <div className="space-y-3">
                        {['Entrada', 'Análise'].map(stage => (
                          <div key={stage}>
                            <p className="text-xs text-gray-500 mb-1">{stage}</p>
                            <div className="flex flex-wrap gap-1">
                              {ALL_FIELDS.filter(f => f.stage === stage).map(field => (
                                <button
                                  key={field.id}
                                  onClick={() => toggleField(field.id)}
                                  className={`px-2 py-1 rounded text-xs transition ${
                                    editPermissions.fields.includes(field.id)
                                      ? 'bg-blue-100 text-blue-700'
                                      : 'bg-gray-100 text-gray-500'
                                  }`}
                                >
                                  {field.label}
                                </button>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* Restore defaults */}
                    <button
                      onClick={() => setEditPermissions(
                        user.role === 'admin' ? DEFAULT_ADMIN_PERMISSIONS : DEFAULT_USER_PERMISSIONS
                      )}
                      className="text-sm text-gray-500 hover:text-gray-700 underline"
                    >
                      Restaurar padrão do perfil
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Fabricantes Tab */}
      {activeTab === 'fabricantes' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <h3 className="font-semibold text-[#003366] mb-4">Fabricantes</h3>
          
          {/* Add Form */}
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={newFabricante}
              onChange={(e) => setNewFabricante(e.target.value)}
              className="flex-1 px-3 py-2 border rounded-lg"
              placeholder="Nome do fabricante"
            />
            <button
              onClick={handleAddFabricante}
              className="px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          
          {/* List */}
          <div className="space-y-2">
            {fabricantes.map((fab) => (
              <div key={fab} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                {editingFabricante?.old === fab ? (
                  <input
                    type="text"
                    value={editingFabricante.new}
                    onChange={(e) => setEditingFabricante({ ...editingFabricante, new: e.target.value })}
                    className="flex-1 px-2 py-1 border rounded mr-2"
                  />
                ) : (
                  <span>{fab}</span>
                )}
                <div className="flex gap-1">
                  {editingFabricante?.old === fab ? (
                    <>
                      <button onClick={handleSaveFabricante} className="p-1 text-green-600 hover:bg-green-100 rounded">
                        <Save className="w-4 h-4" />
                      </button>
                      <button onClick={() => setEditingFabricante(null)} className="p-1 text-gray-600 hover:bg-gray-200 rounded">
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => setEditingFabricante({ old: fab, new: fab })} className="p-1 text-blue-600 hover:bg-blue-100 rounded">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteFabricante(fab)} className="p-1 text-red-600 hover:bg-red-100 rounded">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Frases Defeito Tab */}
      {activeTab === 'frases' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <h3 className="font-semibold text-[#003366] mb-4">Frases Prontas para Defeito Relatado</h3>
          
          {/* Add Form */}
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={newFrase}
              onChange={(e) => setNewFrase(e.target.value)}
              className="flex-1 px-3 py-2 border rounded-lg"
              placeholder="Nova frase pronta..."
            />
            <button
              onClick={handleAddFrase}
              className="px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          
          {/* List */}
          <div className="space-y-2">
            {frasesDefeito.map((frase) => (
              <div key={frase.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                {editingFraseId === frase.id ? (
                  <input
                    type="text"
                    value={editingFraseText}
                    onChange={(e) => setEditingFraseText(e.target.value)}
                    className="flex-1 px-2 py-1 border rounded mr-2"
                  />
                ) : (
                  <span className="text-sm">{frase.texto}</span>
                )}
                <div className="flex gap-1">
                  {editingFraseId === frase.id ? (
                    <>
                      <button onClick={handleSaveFrase} className="p-1 text-green-600 hover:bg-green-100 rounded">
                        <Save className="w-4 h-4" />
                      </button>
                      <button onClick={() => { setEditingFraseId(null); setEditingFraseText(''); }} className="p-1 text-gray-600 hover:bg-gray-200 rounded">
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => { setEditingFraseId(frase.id); setEditingFraseText(frase.texto); }} className="p-1 text-blue-600 hover:bg-blue-100 rounded">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteFraseDefeito(frase.id)} className="p-1 text-red-600 hover:bg-red-100 rounded">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tipos de Serviço Tab */}
      {activeTab === 'servicos' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <h3 className="font-semibold text-[#003366] mb-4">Tipos de Serviço para Análise Técnica</h3>
          
          {/* Add Form */}
          <div className="border rounded-lg p-4 bg-gray-50 mb-4">
            <div className="space-y-3">
              <input
                type="text"
                value={newServico.titulo}
                onChange={(e) => setNewServico(prev => ({ ...prev, titulo: e.target.value }))}
                className="w-full px-3 py-2 border rounded-lg"
                placeholder="Título (Ex: Conjunto Hidráulico)"
              />
              <textarea
                value={newServico.descricao}
                onChange={(e) => setNewServico(prev => ({ ...prev, descricao: e.target.value }))}
                className="w-full px-3 py-2 border rounded-lg"
                rows={3}
                placeholder="Descrição padrão do serviço..."
              />
              <button
                onClick={handleAddServico}
                className="px-4 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Adicionar
              </button>
            </div>
          </div>
          
          {/* List */}
          <div className="space-y-3">
            {tiposServico.map((servico) => (
              <div key={servico.id} className="border rounded-lg p-4 bg-gray-50">
                {editingServicoId === servico.id ? (
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={editingServicoData.titulo}
                      onChange={(e) => setEditingServicoData(prev => ({ ...prev, titulo: e.target.value }))}
                      className="w-full px-2 py-1 border rounded"
                      placeholder="Título"
                    />
                    <textarea
                      value={editingServicoData.descricao}
                      onChange={(e) => setEditingServicoData(prev => ({ ...prev, descricao: e.target.value }))}
                      className="w-full px-2 py-1 border rounded"
                      rows={3}
                      placeholder="Descrição"
                    />
                    <div className="flex gap-2">
                      <button onClick={handleSaveServico} className="px-3 py-1 bg-green-600 text-white rounded text-sm">
                        Salvar
                      </button>
                      <button onClick={() => setEditingServicoId(null)} className="px-3 py-1 border rounded text-sm">
                        Cancelar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-[#003366]">{servico.titulo}</h4>
                      <div className="flex gap-1">
                        <button 
                          onClick={() => { setEditingServicoId(servico.id); setEditingServicoData({ titulo: servico.titulo, descricao: servico.descricaoPadrao }); }} 
                          className="p-1 text-blue-600 hover:bg-blue-100 rounded"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button onClick={() => deleteTipoServico(servico.id)} className="p-1 text-red-600 hover:bg-red-100 rounded">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">{servico.descricaoPadrao}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Termo Tab */}
      {activeTab === 'termo' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
          <h3 className="font-semibold text-[#003366] mb-4">Termo de Garantia</h3>
          
          <div className="space-y-4">
            {/* Objeto da Garantia */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Objeto da Garantia
              </label>
              <textarea
                value={termoEdit.objetoGarantia}
                onChange={(e) => setTermoEdit(prev => ({ ...prev, objetoGarantia: e.target.value }))}
                rows={4}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
              />
            </div>
            
            {/* Exclusões */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Exclusões
              </label>
              <div className="space-y-2 mb-3">
                {termoEdit.exclusoes.map((exclusao, idx) => (
                  <div key={idx} className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                    <span className="flex-1 text-sm">{exclusao}</span>
                    <button
                      onClick={() => handleRemoveExclusao(idx)}
                      className="p-1 text-red-600 hover:bg-red-100 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newExclusao}
                  onChange={(e) => setNewExclusao(e.target.value)}
                  className="flex-1 px-3 py-2 border rounded-lg"
                  placeholder="Nova exclusão..."
                />
                <button
                  onClick={handleAddExclusao}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            {/* Save Button */}
            <button
              onClick={handleSaveTermo}
              className="px-6 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008C44] transition flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Salvar Termo
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
