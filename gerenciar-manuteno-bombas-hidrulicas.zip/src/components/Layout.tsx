import { ReactNode, useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Wrench, 
  FileText, 
  Settings, 
  User, 
  Menu, 
  X,
  LogOut 
} from 'lucide-react';

type Tab = 'reparos' | 'relatorios' | 'admin' | 'perfil';

interface LayoutProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  children: ReactNode;
}

export function Layout({ activeTab, setActiveTab, children }: LayoutProps) {
  const { currentUser, logout } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const tabs = [
    { id: 'reparos' as Tab, label: 'Central de Reparos', shortLabel: 'Reparos', icon: Wrench },
    { id: 'relatorios' as Tab, label: 'Relatórios', shortLabel: 'Relatórios', icon: FileText },
    { id: 'admin' as Tab, label: 'Painel Admin', shortLabel: 'Admin', icon: Settings },
    { id: 'perfil' as Tab, label: 'Perfil', shortLabel: 'Perfil', icon: User },
  ];

  // Filter tabs based on user permissions
  const visibleTabs = tabs.filter(tab => {
    if (!currentUser?.permissions) return tab.id === 'reparos' || tab.id === 'perfil';
    return currentUser.permissions.tabs.includes(tab.id);
  });

  return (
    <div className="min-h-screen min-h-[100dvh] bg-gray-50">
      {/* Header */}
      <header className="bg-[#003366] text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 md:h-16">
            <div className="flex items-center gap-3">
              <div>
                <h1 className="text-lg md:text-xl font-bold">Conab+</h1>
                <p className="text-xs text-white/70 hidden sm:block">Gestão de Manutenção</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              {visibleTabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
                    activeTab === tab.id
                      ? 'bg-[#00A651] text-white'
                      : 'text-white/70 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              ))}
              <button
                onClick={logout}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-white/70 hover:bg-red-500/20 hover:text-white transition ml-2"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </nav>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-white/10 transition"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden border-t border-white/10 px-4 py-3 space-y-1 bg-[#002244]">
            {visibleTabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                  activeTab === tab.id
                    ? 'bg-[#00A651] text-white'
                    : 'text-white/70 hover:bg-white/10 hover:text-white'
                }`}
              >
                <tab.icon className="w-5 h-5" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
            <button
              onClick={logout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-white/70 hover:bg-red-500/20 hover:text-white transition"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Sair</span>
            </button>
          </nav>
        )}
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-6 pb-20 md:pb-6">
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-2 py-2 z-50 safe-area-pb">
        <div className="flex items-center justify-around">
          {visibleTabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition min-w-[60px] ${
                activeTab === tab.id
                  ? 'text-[#00A651]'
                  : 'text-gray-500'
              }`}
            >
              <tab.icon className={`w-5 h-5 ${activeTab === tab.id ? 'text-[#00A651]' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">{tab.shortLabel}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
