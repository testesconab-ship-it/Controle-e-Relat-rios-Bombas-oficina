import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  User, 
  Mail, 
  Shield,
  LogOut,
  Activity,
  CheckCircle,
  Clock
} from 'lucide-react';

export function Perfil() {
  const { currentUser, logout, repairOrders } = useApp();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  if (!currentUser) return null;

  // Stats
  const myOrders = repairOrders.filter(o => o.createdBy === currentUser.id);
  const completedOrders = myOrders.filter(o => o.status === 'concluido').length;
  const pendingOrders = myOrders.filter(o => o.status !== 'concluido').length;

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="space-y-4 md:space-y-6 max-w-2xl mx-auto">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-xl md:text-2xl font-bold text-[#003366]">Meu Perfil</h2>
        <p className="text-gray-500 mt-1 text-sm">Informações da sua conta</p>
      </div>

      {/* Profile Card */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-20 h-20 md:w-24 md:h-24 bg-gradient-to-br from-[#003366] to-[#004d99] rounded-full flex items-center justify-center mb-4">
            <span className="text-2xl md:text-3xl font-bold text-white">
              {currentUser.name.charAt(0).toUpperCase()}
            </span>
          </div>
          <h3 className="text-xl font-semibold text-[#003366]">{currentUser.name}</h3>
          <span className={`mt-2 px-3 py-1 rounded-full text-sm font-medium ${
            currentUser.role === 'admin' 
              ? 'bg-purple-100 text-purple-700' 
              : 'bg-blue-100 text-blue-700'
          }`}>
            {currentUser.role === 'admin' ? 'Administrador' : 'Usuário'}
          </span>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <User className="w-5 h-5 text-[#00A651]" />
            <div>
              <p className="text-xs text-gray-500">Nome</p>
              <p className="font-medium">{currentUser.name}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <Mail className="w-5 h-5 text-[#00A651]" />
            <div>
              <p className="text-xs text-gray-500">E-mail</p>
              <p className="font-medium">{currentUser.email}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <Shield className="w-5 h-5 text-[#00A651]" />
            <div>
              <p className="text-xs text-gray-500">Nível de Acesso</p>
              <p className="font-medium">{currentUser.role === 'admin' ? 'Acesso Total' : 'Acesso Limitado'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
        <div className="flex items-center gap-2 mb-4">
          <Activity className="w-5 h-5 text-[#00A651]" />
          <h3 className="font-semibold text-[#003366]">Minhas Estatísticas</h3>
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold text-[#003366]">{myOrders.length}</p>
            <p className="text-xs text-gray-500">Total Criadas</p>
          </div>
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <div className="flex items-center justify-center gap-1 mb-1">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <p className="text-2xl font-bold text-green-600">{completedOrders}</p>
            </div>
            <p className="text-xs text-gray-500">Concluídas</p>
          </div>
          <div className="text-center p-3 bg-yellow-50 rounded-lg">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Clock className="w-4 h-4 text-yellow-600" />
              <p className="text-2xl font-bold text-yellow-600">{pendingOrders}</p>
            </div>
            <p className="text-xs text-gray-500">Pendentes</p>
          </div>
        </div>
      </div>

      {/* Permissions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6">
        <h3 className="font-semibold text-[#003366] mb-4">Minhas Permissões</h3>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${currentUser.permissions?.tabs?.includes('reparos') ? 'bg-green-500' : 'bg-gray-300'}`} />
            <span className="text-sm">Central de Reparos</span>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${currentUser.permissions?.tabs?.includes('relatorios') ? 'bg-green-500' : 'bg-gray-300'}`} />
            <span className="text-sm">Relatórios</span>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${currentUser.permissions?.tabs?.includes('admin') ? 'bg-green-500' : 'bg-gray-300'}`} />
            <span className="text-sm">Painel Admin</span>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${currentUser.permissions?.canExportPDF ? 'bg-green-500' : 'bg-gray-300'}`} />
            <span className="text-sm">Exportar PDF</span>
          </div>
        </div>
      </div>

      {/* Logout Button */}
      <button
        onClick={() => setShowLogoutConfirm(true)}
        className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-red-50 text-red-600 font-semibold rounded-lg hover:bg-red-100 transition border border-red-200"
      >
        <LogOut className="w-5 h-5" />
        Sair da Conta
      </button>

      {/* Logout Confirmation Modal */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-sm w-full p-6 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <LogOut className="w-8 h-8 text-red-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Sair da Conta?</h3>
            <p className="text-gray-500 mb-6">Tem certeza que deseja encerrar sua sessão?</p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 px-4 py-2 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition"
              >
                Cancelar
              </button>
              <button
                onClick={handleLogout}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
              >
                Sair
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
